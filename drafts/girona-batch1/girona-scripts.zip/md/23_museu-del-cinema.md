# 23 · Museu del Cinema

*281 words · about 112 seconds at an unhurried pace*

## Clean script

This museum tells the story of the moving image from long before anyone had a film camera.

You are on the west bank of the Onyar, outside the old headquarters of the city water company. Look up for the tower on its roof. Locals still call the building the Casa de les Aigües, the House of the Waters. That's the Museu del Cinema.

It opened on the eighth of April, nineteen ninety eight, after the city bought a remarkable private collection in nineteen ninety four. That collection belonged to Tomàs Mallol, a filmmaker and collector from Girona, and it holds around twenty thousand pieces. There are shadow puppets, magic lanterns, optical toys, early cameras and projectors, posters and films, the whole prehistory and history of cinema.

Have a look for the shadow theatres and the magic lanterns. Long before films, people sat in the dark and watched light play on a wall. Those objects show that the desire to see pictures move is centuries older than the cinema itself. Some of the devices can be tried, so you can make an image move with your own hands.

What's worth knowing is how personal all of this is. It began with one man's obsession, built up over decades, and it ended up in a building designed to store water. It is a quietly eccentric museum, and its strength is that it was collected by someone who simply loved how pictures came alive.

[beat]

Once you're done, walk the few minutes north to the river and stand on the Pont de Sant Agustí. The coloured house fronts reflected in the Onyar are a moving picture of their own, and the best show in town.

## TTS-safe script

This museum tells the story of the moving image from long before anyone had a film camera.

You are on the west bank of the Oonyar, outside the old headquarters of the city water company. Look up for the tower on its roof. Locals still call the building the Kasa duh less Eyegwus, the House of the Waters. That's the Moozayoo del Seenema.

It opened on the eighth of April, nineteen ninety eight, after the city bought a remarkable private collection in nineteen ninety four. That collection belonged to Toomas Mayol, a filmmaker and collector from Jeerohna, and it holds around twenty thousand pieces. There are shadow puppets, magic lanterns, optical toys, early cameras and projectors, posters and films, the whole prehistory and history of cinema.

Have a look for the shadow theatres and the magic lanterns. Long before films, people sat in the dark and watched light play on a wall. Those objects show that the desire to see pictures move is centuries older than the cinema itself. Some of the devices can be tried, so you can make an image move with your own hands.

What's worth knowing is how personal all of this is. It began with one man's obsession, built up over decades, and it ended up in a building designed to store water. It is a quietly eccentric museum, and its strength is that it was collected by someone who simply loved how pictures came alive.

Once you're done, walk the few minutes north to the river and stand on the Pon duh San Agoostee. The coloured house fronts reflected in the Oonyar are a moving picture of their own, and the best show in town.
