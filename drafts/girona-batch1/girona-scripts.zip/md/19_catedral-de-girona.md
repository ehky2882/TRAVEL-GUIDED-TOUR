# 19 · Catedral de Girona

*322 words · about 129 seconds at an unhurried pace*

## Clean script

Look up. That is roughly ninety steps between you and the door, and behind the door is the widest Gothic nave in the world.

You are at the foot of the great stairway in the Plaça de la Catedral, in the old town. In front of you the steps rise to a tall Baroque front, with a bell tower above it. Take your time with the climb. Everyone does.

The stairway was finished in sixteen oh seven, and the Baroque front was begun at around the same time, though its top was only completed in nineteen sixty one. So the face you see took more than three and a half centuries to finish. If the scene feels familiar, it may be because the cathedral and these steps stood in for the Great Sept of Baelor in the sixth series of Game of Thrones.

Now, the inside. In fourteen sixteen the builders, led by Guillem Bofill and Antoni Canet, took a bold decision. Instead of a nave with two aisles, they covered the whole church with one single span. The result is a nave almost twenty three metres wide, the widest Gothic nave anywhere, and the vault rises about thirty five metres above the floor. When you walk in, there are no rows of columns. There is just one enormous room.

One more thing to find later, from the cloister: an older, plainer tower on the north side. That is the tower of Charlemagne, begun in the early eleventh century, the survivor of the Romanesque cathedral that stood here before. The builders kept it and used it to help brace the new one.

[beat]

Inside, find the museum and its Tapestry of Creation, a Romanesque embroidery about nine hundred years old, and one of the great treasures of Catalonia. Then come back out to the top of the steps and look down. The whole of the old town is laid out at your feet.

## TTS-safe script

Look up. That is roughly ninety steps between you and the door, and behind the door is the widest Gothic nave in the world.

You are at the foot of the great stairway in the Plassa duh la Katuhdral, in the old town. In front of you the steps rise to a tall Baroque front, with a bell tower above it. Take your time with the climb. Everyone does.

The stairway was finished in sixteen oh seven, and the Baroque front was begun at around the same time, though its top was only completed in nineteen sixty one. So the face you see took more than three and a half centuries to finish. If the scene feels familiar, it may be because the cathedral and these steps stood in for the Great Sept of Bayler in the sixth series of Game of Thrones.

Now, the inside. In fourteen sixteen the builders, led by Geeyem Boofeel and Antonee Kanet, took a bold decision. Instead of a nave with two aisles, they covered the whole church with one single span. The result is a nave almost twenty three metres wide, the widest Gothic nave anywhere, and the vault rises about thirty five metres above the floor. When you walk in, there are no rows of columns. There is just one enormous room.

One more thing to find later, from the cloister: an older, plainer tower on the north side. That is the tower of Charlemagne, begun in the early eleventh century, the survivor of the Romanesque cathedral that stood here before. The builders kept it and used it to help brace the new one.

Inside, find the museum and its Tapestry of Creation, a Romanesque embroidery about nine hundred years old, and one of the great treasures of Catalonia. Then come back out to the top of the steps and look down. The whole of the old town is laid out at your feet.
