# 01 · Casa Cacao

*332 words · about 133 seconds at an unhurried pace*

## Clean script

The building on this corner of the square smells faintly of chocolate, and that is entirely deliberate.

Plaça de Catalunya is the wide square laid over the river Onyar, just south of the old town. With the water behind you, find number twenty-three: a tall, pale building on the edge of the square, with a shop and a bar at street level. That is Casa Cacao.

It belongs to the Roca family, the three brothers behind El Celler de Can Roca, and it opened in February twenty twenty as two ideas under one roof. On the ground floor, Jordi Roca, the youngest brother and the family's pastry chef, runs a bean to bar chocolate workshop. Bean to bar means they take raw cocoa beans and do every step themselves, the roasting, the grinding, the long slow mixing, all the way to the finished bar. Upstairs, Anna Payet, who is married to the eldest brother, Joan, runs a hotel of fifteen rooms.

Now look up at the roofline. Breakfast is served on the rooftop terrace, with the old town spread out across the river, and the breakfast menu is Joan Roca's own. So for the price of a room you can eat a breakfast designed by a chef with three Michelin stars, which is rather a good trick.

What I like is where they put it. Not in a medieval palace up the hill, but in a mid twentieth century block on a busy square that most people cross on their way to somewhere else. The family took their most playful project and set it on the ordinary side of the river, and let the old town be the view.

[beat]

Before you go, walk to the corner of the square where the old stone bridge, the Pont de Pedra, crosses the Onyar. Stand in the middle of it and look upstream. That is your first proper look at the painted houses along the river, and it is a very good place to begin.

## TTS-safe script

The building on this corner of the square smells faintly of chocolate, and that is entirely deliberate.

Plassa duh Kataloonya is the wide square laid over the river Oonyar, just south of the old town. With the water behind you, find number twenty three: a tall, pale building on the edge of the square, with a shop and a bar at street level. That is Kasa Kakow.

It belongs to the Rokka family, the three brothers behind El Suhyay duh Kan Rokka, and it opened in February twenty twenty as two ideas under one roof. On the ground floor, Jordee Rokka, the youngest brother and the family's pastry chef, runs a bean to bar chocolate workshop. Bean to bar means they take raw cocoa beans and do every step themselves, the roasting, the grinding, the long slow mixing, all the way to the finished bar. Upstairs, Anna Pyet, who is married to the eldest brother, Jooahn, runs a hotel of fifteen rooms.

Now look up at the roofline. Breakfast is served on the rooftop terrace, with the old town spread out across the river, and the breakfast menu is Jooahn Rokka's own. So for the price of a room you can eat a breakfast designed by a chef with three Michelin stars, which is rather a good trick.

What I like is where they put it. Not in a medieval palace up the hill, but in a mid twentieth century block on a busy square that most people cross on their way to somewhere else. The family took their most playful project and set it on the ordinary side of the river, and let the old town be the view.

Before you go, walk to the corner of the square where the old stone bridge, the Pon duh Pedra, crosses the Oonyar. Stand in the middle of it and look upstream. That is your first proper look at the painted houses along the river, and it is a very good place to begin.
