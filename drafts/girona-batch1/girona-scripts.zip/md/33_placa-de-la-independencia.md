# 33 · Plaça de la Independència

*298 words · about 119 seconds at an unhurried pace*

## Clean script

This square was built on the ruins of a convent, and it is named after a siege.

You are in the Plaça de la Independència, on the west bank of the river, right by the Pont de Sant Agustí. Stand by the monument in the middle. Around you, an even ring of arcades with restaurants and café tables under the arches, all in the same calm, neo classical style.

The square was designed by Martí Sureda on the site of the old convent of Sant Agustí, which was pulled down in eighteen forty one. That is why locals still call it the Plaça de Sant Agustí, and why the footbridge next to it has the same name. Its name was changed more than once over the century, and in eighteen sixty eight it became the Plaça de la Independència.

Now look at the monument. It remembers the defenders of Girona during the long siege of eighteen oh nine, when the city held out for months against Napoleon's armies before it finally fell. It was one of the most famous episodes of the Peninsular War, and it is still a source of great local pride.

What I like about this square is the contrast with the old town across the river. Over there everything is twisting and uphill. Here, everything is level, symmetrical and orderly. It's the nineteenth century city, laying out a square as a statement of reason and civic pride, and then filling it with restaurant tables, which is exactly what squares are for.

[beat]

For a final view, walk onto the Pont de Sant Agustí next to the square and look back at the coloured houses along the river. Then come back here for dinner under the arches, as Girona has done for well over a century.

## TTS-safe script

This square was built on the ruins of a convent, and it is named after a siege.

You are in the Plassa duh la Indeppendensseea, on the west bank of the river, right by the Pon duh San Agoostee. Stand by the monument in the middle. Around you, an even ring of arcades with restaurants and cafe tables under the arches, all in the same calm, neo classical style.

The square was designed by Martee Sooraida on the site of the old convent of San Agoostee, which was pulled down in eighteen forty one. That is why locals still call it the Plassa duh San Agoostee, and why the footbridge next to it has the same name. Its name was changed more than once over the century, and in eighteen sixty eight it became the Plassa duh la Indeppendensseea.

Now look at the monument. It remembers the defenders of Jeerohna during the long siege of eighteen oh nine, when the city held out for months against Napoleon's armies before it finally fell. It was one of the most famous episodes of the Peninsular War, and it is still a source of great local pride.

What I like about this square is the contrast with the old town across the river. Over there everything is twisting and uphill. Here, everything is level, symmetrical and orderly. It's the nineteenth century city, laying out a square as a statement of reason and civic pride, and then filling it with restaurant tables, which is exactly what squares are for.

For a final view, walk onto the Pon duh San Agoostee next to the square and look back at the coloured houses along the river. Then come back here for dinner under the arches, as Jeerohna has done for well over a century.
