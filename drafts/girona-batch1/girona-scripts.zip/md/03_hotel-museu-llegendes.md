# 03 · Hotel Museu Llegendes de Girona

*306 words · about 122 seconds at an unhurried pace*

## Clean script

Every old city has its stories, and this one decided to sleep inside them.

You are at the top end of the old town, on the street called Portal de la Barca, a short walk below the monastery of Sant Pere de Galligants. The hotel is in a restored eighteenth century building of fifteen rooms. Its full name, the Museum Hotel of the Legends of Girona, tells you exactly what it is about.

The theme is the folklore of the city, and Girona has plenty. The most famous is the legend of the flies of Saint Narcís. The story goes that when a French army besieged the city in twelve eighty five, soldiers broke open the tomb of the saint, and a cloud of flies poured out and drove them away. The fly has been Girona's mascot ever since, and you will see it on everything from sweets to street decorations.

Then there is the lioness, a small stone figure climbing a column by the basilica of Sant Feliu, a short walk south of here. Tradition says that if you kiss her bottom, you will come back to Girona. People queue to do it.

Here is what I find interesting about a hotel like this. In most cities legends are something you are told on a walking tour and then forget. Girona actually lives by them. The flies, the lioness, the giant who supposedly founded the city: they turn up in festivals, in shop windows and on the menus. A hotel built on them is not a gimmick so much as an accurate reading of the place.

[beat]

From the door, walk uphill to the church of Sant Pere de Galligants, just round the corner. Its cloister is full of carved stone creatures from the twelfth century, and they are every bit as strange as the legends.

## TTS-safe script

Every old city has its stories, and this one decided to sleep inside them.

You are at the top end of the old town, on the street called Portal duh la Barka, a short walk below the monastery of San Pairuh duh Galeegans. The hotel is in a restored eighteenth century building of fifteen rooms. Its full name, the Museum Hotel of the Legends of Jeerohna, tells you exactly what it is about.

The theme is the folklore of the city, and Jeerohna has plenty. The most famous is the legend of the flies of Saint Narsees. The story goes that when a French army besieged the city in twelve eighty five, soldiers broke open the tomb of the saint, and a cloud of flies poured out and drove them away. The fly has been Jeerohna's mascot ever since, and you will see it on everything from sweets to street decorations.

Then there is the lioness, a small stone figure climbing a column by the basilica of San Feleeoo, a short walk south of here. Tradition says that if you kiss her bottom, you will come back to Jeerohna. People queue to do it.

Here is what I find interesting about a hotel like this. In most cities legends are something you are told on a walking tour and then forget. Jeerohna actually lives by them. The flies, the lioness, the giant who supposedly founded the city: they turn up in festivals, in shop windows and on the menus. A hotel built on them is not a gimmick so much as an accurate reading of the place.

From the door, walk uphill to the church of San Pairuh duh Galeegans, just round the corner. Its cloister is full of carved stone creatures from the twelfth century, and they are every bit as strange as the legends.
