# 18 · Banys Àrabs

*319 words · about 128 seconds at an unhurried pace*

## Clean script

These are called the Arab Baths, and they were built by Christians, centuries after Girona had stopped being a Muslim city.

You are at the north end of the old town, just below the cathedral, by the entrance to the baths. From outside, look for a small, squat building with a little round lantern rising from its roof. That lantern is the thing you have really come to see, and from inside it is even better.

The baths are first mentioned in eleven ninety four, when the king granted the cathedral an income from them. So these are Romanesque, a Christian building, but laid out on the pattern of the bathhouses of the Islamic world, which were themselves descended from Roman ones. Hence the name, and hence the slight confusion. They were damaged in twelve eighty five, when a French army besieged the city, and they worked as public baths until around the fourteenth century.

Go inside and the first proper room is the changing room, the apodyterium. In the middle is an eight sided pool ringed by eight slim columns with carved capitals, and above them that little lantern, letting down a soft circle of light. It is one of the most beautiful small rooms in Catalonia. From there you pass through the cold room, the warm room and the hot room, exactly as a Roman would have done.

And here's the thing. This single room carries three traditions at once. Roman bathing, the Islamic bathhouse and the Jewish ritual bath all fed into the way it was built. In a city where Christians, Jews and Muslims lived for centuries, a bathhouse turns out to be a very good portrait of the place.

[beat]

When you come out, look for the little gardens and the steps that climb towards the city wall nearby. From higher up, the view back down over that lantern is the best one you'll get.

## TTS-safe script

These are called the Arab Baths, and they were built by Christians, centuries after Jeerohna had stopped being a Muslim city.

You are at the north end of the old town, just below the cathedral, by the entrance to the baths. From outside, look for a small, squat building with a little round lantern rising from its roof. That lantern is the thing you have really come to see, and from inside it is even better.

The baths are first mentioned in eleven ninety four, when the king granted the cathedral an income from them. So these are Romanesque, a Christian building, but laid out on the pattern of the bathhouses of the Islamic world, which were themselves descended from Roman ones. Hence the name, and hence the slight confusion. They were damaged in twelve eighty five, when a French army besieged the city, and they worked as public baths until around the fourteenth century.

Go inside and the first proper room is the changing room, the apoditeereeum. In the middle is an eight sided pool ringed by eight slim columns with carved capitals, and above them that little lantern, letting down a soft circle of light. It is one of the most beautiful small rooms in Catalonia. From there you pass through the cold room, the warm room and the hot room, exactly as a Roman would have done.

And here's the thing. This single room carries three traditions at once. Roman bathing, the Islamic bathhouse and the Jewish ritual bath all fed into the way it was built. In a city where Christians, Jews and Muslims lived for centuries, a bathhouse turns out to be a very good portrait of the place.

When you come out, look for the little gardens and the steps that climb towards the city wall nearby. From higher up, the view back down over that lantern is the best one you'll get.
