# 28 · Farinera Teixidor

*295 words · about 118 seconds at an unhurried pace*

## Clean script

A flour mill is not supposed to look like this.

You are on Carrer de Santa Eugènia, on the west side of the city, a little way from the river. Look across at the building with the pale front, the bright ceramic details and the sharp pinnacles along the top. That is the Farinera Teixidor, the Teixidor flour mill.

It was designed by Rafael Masó, Girona's great architect, for the industrialist Alfons Teixidor. Work began in nineteen ten and nineteen eleven and carried on in stages until nineteen twenty three. It was a working factory, built to grind wheat, and Masó gave it the dignity of a public building.

Look up at the top of the front. The main pinnacle is said to take the form of an ear of wheat, the very thing the mill was built to turn into flour. Then look at the glazed ceramic pieces set into the walls. When the building was restored between nineteen ninety seven and nineteen ninety nine, a ceramicist remade and reglazed pieces to match. For years after that it was home to the newspaper El Punt.

And here's the thing. In the early twentieth century, Catalan industrialists often wanted their factories to say something about them, and their architects took them at their word. Masó treated a mill as a chance to show that ordinary work deserved beauty. That idea, that a factory could be a piece of art, is very much of its time, and you won't see it done better in this city.

[beat]

From here, walk back east towards the river and on into the old town. Masó was born in a white house on the Onyar, and you can find it from the bridges, which makes a satisfying end to the story.

## TTS-safe script

A flour mill is not supposed to look like this.

You are on Karreh duh Santa Ayoozhenya, on the west side of the city, a little way from the river. Look across at the building with the pale front, the bright ceramic details and the sharp pinnacles along the top. That is the Fareenaira Tusheedor, the Tusheedor flour mill.

It was designed by Rafa el Massoh, Jeerohna's great architect, for the industrialist Alfons Tusheedor. Work began in nineteen ten and nineteen eleven and carried on in stages until nineteen twenty three. It was a working factory, built to grind wheat, and Massoh gave it the dignity of a public building.

Look up at the top of the front. The main pinnacle is said to take the form of an ear of wheat, the very thing the mill was built to turn into flour. Then look at the glazed ceramic pieces set into the walls. When the building was restored between nineteen ninety seven and nineteen ninety nine, a ceramicist remade and reglazed pieces to match. For years after that it was home to the newspaper El Poon.

And here's the thing. In the early twentieth century, Catalan industrialists often wanted their factories to say something about them, and their architects took them at their word. Massoh treated a mill as a chance to show that ordinary work deserved beauty. That idea, that a factory could be a piece of art, is very much of its time, and you won't see it done better in this city.

From here, walk back east towards the river and on into the old town. Massoh was born in a white house on the Oonyar, and you can find it from the bridges, which makes a satisfying end to the story.
