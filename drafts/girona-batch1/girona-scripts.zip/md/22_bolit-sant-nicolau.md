# 22 · Bòlit Sant Nicolau

*307 words · about 123 seconds at an unhurried pace*

## Clean script

A tiny twelfth century chapel, and inside it, art that might have been made last month.

You are at the north end of the old town, a few steps from the monastery of Sant Pere de Galligants. Look for a small, low Romanesque chapel with a rounded end. That is the chapel of Sant Nicolau. Today it is one of the spaces of the Bòlit, Girona's centre for contemporary art.

The Bòlit was set up by the city in two thousand and eight to research, produce and show contemporary work. It doesn't have one big gallery; instead it uses several spaces around Girona, and this chapel is the most surprising of them. The exhibitions change through the year, and they are often installations made for this one room. In recent seasons artists have filled it with video, sculpture and new pieces that respond to questions of heritage and memory.

Have a look at the building itself first. The walls are thick, the windows small, and the end of the chapel curves round in the classic Romanesque apse. It was built to hold the dark, the candlelight and the quiet, and that is exactly what makes it so good for art today. There is nothing else to look at.

What I like is the boldness of the idea. A city this old could have treated a twelfth century chapel as something to be kept behind a rope. Instead it hands it to living artists and asks them to have a conversation with it. Some of the pieces work and some don't, but the building always gives as good as it gets.

[beat]

Afterwards, step next door into the cloister of Sant Pere de Galligants. Its carved capitals were the cutting edge of their own day, and it's a nice way to see that every age's art was once new.

## TTS-safe script

A tiny twelfth century chapel, and inside it, art that might have been made last month.

You are at the north end of the old town, a few steps from the monastery of San Pairuh duh Galeegans. Look for a small, low Romanesque chapel with a rounded end. That is the chapel of San Neekoolow. Today it is one of the spaces of the Bolleet, Jeerohna's centre for contemporary art.

The Bolleet was set up by the city in two thousand and eight to research, produce and show contemporary work. It doesn't have one big gallery; instead it uses several spaces around Jeerohna, and this chapel is the most surprising of them. The exhibitions change through the year, and they are often installations made for this one room. In recent seasons artists have filled it with video, sculpture and new pieces that respond to questions of heritage and memory.

Have a look at the building itself first. The walls are thick, the windows small, and the end of the chapel curves round in the classic Romanesque apse. It was built to hold the dark, the candlelight and the quiet, and that is exactly what makes it so good for art today. There is nothing else to look at.

What I like is the boldness of the idea. A city this old could have treated a twelfth century chapel as something to be kept behind a rope. Instead it hands it to living artists and asks them to have a conversation with it. Some of the pieces work and some don't, but the building always gives as good as it gets.

Afterwards, step next door into the cloister of San Pairuh duh Galeegans. Its carved capitals were the cutting edge of their own day, and it's a nice way to see that every age's art was once new.
