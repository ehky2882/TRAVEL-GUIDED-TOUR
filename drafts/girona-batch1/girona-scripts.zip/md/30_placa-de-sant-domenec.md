# 30 · Plaça de Sant Domènec

*278 words · about 111 seconds at an unhurried pace*

## Clean script

This is the quietest square at the top of the old town, and it is the university's front room.

You are in the Plaça de Sant Domènec, at the top of the old town. On one side is Les Àligues, the Renaissance university building. On the other, a long flight of steps leads up to the old Gothic convent of Sant Domènec, now part of the university.

The convent was founded by the Dominican friars in the middle of the thirteenth century, and its church was consecrated in thirteen thirty nine. It has two cloisters, a church and the convent buildings, all Gothic. In the nineteenth century the army took it over and turned it into barracks, which is how a lot of the great religious buildings of Spain survived and suffered at the same time.

Around the turn of the millennium it became the home of the university's Faculty of Arts. So the friars' cloisters now hold lecture rooms and seminar rooms, and the stairs where friars once walked are where students sit to talk between classes.

And here's the thing. Look at how the city has used what it inherited. A Dominican convent, a Renaissance college, an army barracks, and now a university quarter. Girona didn't replace these buildings. It found new tenants for them, again and again, and the square has stayed alive because of it.

[beat]

If the convent is open, climb the steps and look into the Gothic cloister. Then walk to the back of the square and find a way up onto the city wall, which runs right behind these buildings and gives you a view over the whole of the old town.

## TTS-safe script

This is the quietest square at the top of the old town, and it is the university's front room.

You are in the Plassa duh San Doomennek, at the top of the old town. On one side is less Aleegus, the Renaissance university building. On the other, a long flight of steps leads up to the old Gothic convent of San Doomennek, now part of the university.

The convent was founded by the Dominican friars in the middle of the thirteenth century, and its church was consecrated in thirteen thirty nine. It has two cloisters, a church and the convent buildings, all Gothic. In the nineteenth century the army took it over and turned it into barracks, which is how a lot of the great religious buildings of Spain survived and suffered at the same time.

Around the turn of the millennium it became the home of the university's Faculty of Arts. So the friars' cloisters now hold lecture rooms and seminar rooms, and the stairs where friars once walked are where students sit to talk between classes.

And here's the thing. Look at how the city has used what it inherited. A Dominican convent, a Renaissance college, an army barracks, and now a university quarter. Jeerohna didn't replace these buildings. It found new tenants for them, again and again, and the square has stayed alive because of it.

If the convent is open, climb the steps and look into the Gothic cloister. Then walk to the back of the square and find a way up onto the city wall, which runs right behind these buildings and gives you a view over the whole of the old town.
