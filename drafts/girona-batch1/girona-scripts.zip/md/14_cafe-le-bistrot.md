# 14 · Cafè Le Bistrot

*297 words · about 119 seconds at an unhurried pace*

## Clean script

These are some of the best seats in the city, and they are on a staircase.

You are on the Pujada de Sant Domènec, the broad flight of stone steps in the old town that climbs towards the church of Sant Martí Sacosta. Halfway up, the café's tables spill out across the steps. Look up the stairs to the church front at the top, and down towards the old shops below.

Le Bistrot has been here since the late nineteen seventies, and it is one of the city's true classics. The thing to order is the pizza de pagès. It is made on a slice of the round country loaf of Catalonia, the pa de pagès, toasted on one side and baked with its topping on the other. There are about twenty variations.

Now have a look around you. You are sitting in the middle of a theatre set. The stairs climb to a seventeenth century church, the old walls rise on either side, and almost everyone who walks through the old town ends up passing these tables. It's one of the most photographed corners of Girona, and once you have sat here you understand why.

And here's the thing. Girona is a hill town, and a hill town is a town of stairs. Most cities treat a staircase as something to get up as quickly as possible. Here they put tables on it and turned it into a room. That might be the most Catalan piece of urban design in the whole city.

[beat]

Before you leave, look at the old theatre building next door, now a bicycle shop. Then carry on to the top of the steps, where the old university buildings begin. That corner is one of the quietest and loveliest in the old town.

## TTS-safe script

These are some of the best seats in the city, and they are on a staircase.

You are on the Poojahda duh San Doomennek, the broad flight of stone steps in the old town that climbs towards the church of San Martee Sakosta. Halfway up, the cafe's tables spill out across the steps. Look up the stairs to the church front at the top, and down towards the old shops below.

luh Beestro has been here since the late nineteen seventies, and it is one of the city's true classics. The thing to order is the pizza duh pajess. It is made on a slice of the round country loaf of Catalonia, the pa duh pajess, toasted on one side and baked with its topping on the other. There are about twenty variations.

Now have a look around you. You are sitting in the middle of a theatre set. The stairs climb to a seventeenth century church, the old walls rise on either side, and almost everyone who walks through the old town ends up passing these tables. It's one of the most photographed corners of Jeerohna, and once you have sat here you understand why.

And here's the thing. Jeerohna is a hill town, and a hill town is a town of stairs. Most cities treat a staircase as something to get up as quickly as possible. Here they put tables on it and turned it into a room. That might be the most Catalan piece of urban design in the whole city.

Before you leave, look at the old theatre building next door, now a bicycle shop. Then carry on to the top of the steps, where the old university buildings begin. That corner is one of the quietest and loveliest in the old town.
