# 29 · Edifici de les Aligues

*312 words · about 125 seconds at an unhurried pace*

## Clean script

The University of Girona is quite young, and it lives in one of the oldest university buildings in Catalonia.

You are in the Plaça de Sant Domènec, at the top of the old town. Face the long building with the carved Renaissance doorway and the stone front. That is Les Àligues, the Eagles, and today it is the seat of the university's rector.

The name comes from the eagle with two heads, the emblem of the Habsburg dynasty, who ruled Spain at the time. The first stone was laid in December fifteen sixty one, and by fifteen seventy two the old university of Girona had begun to teach here. Its roots went back further, to the fifteenth century, when a royal decree had set up a place of study in the city.

Look at the doorway and the front above it. That carved stone is the only part left from the sixteenth century. Over the following centuries the old university closed and the building declined, and by the late twentieth century much of it was in ruins. When the modern University of Girona was founded in December nineteen ninety one, the local architects Josep Fuses and Joan Maria Viader restored it, putting back its original L shape and treating the courtyard almost like a public square.

What's worth knowing is that this restoration is a big part of the reason the old town feels alive. Instead of building a campus out in the suburbs, the university came back into these old buildings. Students now fill the steps and the squares, and an old quarter that might have become a museum is still a place where people learn.

[beat]

Take a look at the university's own crest when you see one around town. Its design is based on this very front. Then cross the square to the old convent of Sant Domènec, just opposite.

## TTS-safe script

The University of Jeerohna is quite young, and it lives in one of the oldest university buildings in Catalonia.

You are in the Plassa duh San Doomennek, at the top of the old town. Face the long building with the carved Renaissance doorway and the stone front. That is less Aleegus, the Eagles, and today it is the seat of the university's rector.

The name comes from the eagle with two heads, the emblem of the Habsburg dynasty, who ruled Spain at the time. The first stone was laid in December fifteen sixty one, and by fifteen seventy two the old university of Jeerohna had begun to teach here. Its roots went back further, to the fifteenth century, when a royal decree had set up a place of study in the city.

Look at the doorway and the front above it. That carved stone is the only part left from the sixteenth century. Over the following centuries the old university closed and the building declined, and by the late twentieth century much of it was in ruins. When the modern University of Jeerohna was founded in December nineteen ninety one, the local architects Joozep Foozus and Jooahn Mareea Veeaday restored it, putting back its original L shape and treating the courtyard almost like a public square.

What's worth knowing is that this restoration is a big part of the reason the old town feels alive. Instead of building a campus out in the suburbs, the university came back into these old buildings. Students now fill the steps and the squares, and an old quarter that might have become a museum is still a place where people learn.

Take a look at the university's own crest when you see one around town. Its design is based on this very front. Then cross the square to the old convent of San Doomennek, just opposite.
