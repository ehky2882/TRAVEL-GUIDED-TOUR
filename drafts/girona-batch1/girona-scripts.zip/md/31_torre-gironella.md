# 31 · Torre Gironella

*293 words · about 117 seconds at an unhurried pace*

## Clean script

This is the highest point of the old city walls, and it is where the story of Girona's defence began and ended.

You are at the top of the wall walk, at the eastern edge of the old town, among the ruins of the Gironella tower. Look out over the stone walls and towers falling away down the hill to the river, with the cathedral and the roofs below you.

The tower sits at the very top of the Roman wall. When the Romans strengthened the walls in the late third century, they added square towers, and one of them stood here. Around the year one thousand it became part of a castle, the castle of Gironella. Legend says the city was founded by a giant called Gerió, which is one story for where the name Girona comes from.

There's a darker chapter too. In thirteen ninety one, when anti Jewish riots swept through the cities of Catalonia, the Jews of Girona took refuge in this tower, and some were held here to be pressed into converting. The tower later fell into ruin, and in eighteen fourteen, at the end of the French occupation, Napoleon's troops blew up the main fortifications, Gironella among them.

What I find moving about this spot is that it holds both the city's strength and its failures. The walls that kept Girona safe through siege after siege are the same walls where one of its own communities could only hide. Up here, with the view at your feet, it is worth remembering both.

[beat]

From here, follow the wall walk back down the hill towards the cathedral. It runs for a good stretch along the old defences, and at every turn you get a different view over the roofs.

## TTS-safe script

This is the highest point of the old city walls, and it is where the story of Jeerohna's defence began and ended.

You are at the top of the wall walk, at the eastern edge of the old town, among the ruins of the Jeeroonayya tower. Look out over the stone walls and towers falling away down the hill to the river, with the cathedral and the roofs below you.

The tower sits at the very top of the Roman wall. When the Romans strengthened the walls in the late third century, they added square towers, and one of them stood here. Around the year one thousand it became part of a castle, the castle of Jeeroonayya. Legend says the city was founded by a giant called Jeree oh, which is one story for where the name Jeerohna comes from.

There's a darker chapter too. In thirteen ninety one, when anti Jewish riots swept through the cities of Catalonia, the Jews of Jeerohna took refuge in this tower, and some were held here to be pressed into converting. The tower later fell into ruin, and in eighteen fourteen, at the end of the French occupation, Napoleon's troops blew up the main fortifications, Jeeroonayya among them.

What I find moving about this spot is that it holds both the city's strength and its failures. The walls that kept Jeerohna safe through siege after siege are the same walls where one of its own communities could only hide. Up here, with the view at your feet, it is worth remembering both.

From here, follow the wall walk back down the hill towards the cathedral. It runs for a good stretch along the old defences, and at every turn you get a different view over the roofs.
