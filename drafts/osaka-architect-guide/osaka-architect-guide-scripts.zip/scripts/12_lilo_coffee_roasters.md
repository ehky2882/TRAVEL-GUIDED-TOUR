# 12 · LiLo Coffee Roasters

**Category:** Drink · **Coordinates (WGS-84):** 34.674063, 135.498223 · **Length:** 294 words (about 118 s at 150 wpm)

## Script (clean)

This coffee shop started life as a hairdresser's coffee bar. The hairdresser just wanted a better house blend.

A back street in Nishi-Shinsaibashi, the Amerikamura side of Midosuji, outside a small shopfront on the ground floor of a narrow building. Look in and you'll see a counter, baristas working very close to the customers, and bean containers stacked almost to the ceiling.

It opened on the eighth of August 2014. The owner, Hotta, ran the beauty salon upstairs and served coffee to his clients. He wanted to roast his own, so he took over the ground floor below. The head roaster, Nakamura, started on a one-kilo roaster. These days it's an eight-kilo machine, roasting several hundred kilos a month.

Have a look at the cards on the counter. Each bean has its own illustrated card with its origin, how it tastes and what to brew it with. Ask, and the barista on shift will point you to their favourite of the day and two or three others to suit your taste. Then you choose the method: paper filter, metal filter, French press or cold brew. There are usually about twenty beans on offer.

And here's the bit worth knowing. Most specialty coffee chases a clean cup, polite and balanced. Nakamura goes the other way. He's looking for a strong first impression, a bean with character, something that surprises you on the first sip, even if it's not quite so tidy.

*[beat]*

From here, Triangle Park is about two minutes' walk, the centre of Amerikamura, and if you like this, the shop has a little sister elsewhere in the city, LiLo Coffee Kissa, done up as an old-fashioned Japanese coffee house. Or cross Midosuji for Shinsaibashi-suji and the old Daimaru department store.

## TTS-safe version

See `12_lilo_coffee_roasters_tts-safe.txt`. Spoken title: **Leeloh Coffee Roasters**.

## Respellings used

| Written | Spoken |
|---|---|
| Amerikamura | Ahmayree kah moorah |
| Daimaru | Dye mahroo |
| Hotta | Hottah |
| LiLo | Leeloh |
| LiLo Coffee Kissa | Leeloh Coffee Keessah |
| Midosuji | Meedoh soojee |
| Nakamura | Nahkah moorah |
| Nishi-Shinsaibashi | Neeshee Sheen sye bahshee |
| Shinsaibashi | Sheen sye bahshee |
| Shinsaibashi-suji | Sheen sye bahshee soojee |

## Primary sources read before writing

- https://kurasu.kyoto/blogs/kurasu-journal/lilo-coffee-roasters-osaka-december-2017s-kurasucoffee-roaster
- https://www.timeout.com/osaka/restaurants/lilo-coffee-roasters
