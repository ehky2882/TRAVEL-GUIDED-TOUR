# 23 · Sumiyoshi Taisha

**Category:** Visit · **Coordinates (WGS-84):** 34.613003, 135.493101 · **Length:** 353 words (about 141 s at 150 wpm)

## Script (clean)

This shrine is the head of some two thousand three hundred Sumiyoshi shrines across Japan. And its buildings show you what Japanese architecture looked like before Buddhism arrived.

You should be at the foot of the Sorihashi, the bright red bridge that arches so steeply over the pond that it's nearly a half circle. It's the symbol of the shrine. Crossing it is part of the visit, and it's steeper than it looks.

Cross over and walk ahead to the main halls. There are four of them, and all four are National Treasures. The first three stand in a straight line, one behind the other, and the fourth sits beside the third. The gods of the first three are gods of the sea, which is why sailors, fishermen and merchants have come here for centuries. The fourth is for the Empress Jingu.

Have a look at the halls themselves. Vermilion posts, white walls, and a plain, straight roof with no curve at all. Compare it with the swooping roofs of the temples elsewhere in the city. The entrance is in the gable end, at the front, and inside are two rooms, one behind the other. This style is called Sumiyoshi-zukuri, and it's one of the oldest kinds of shrine in Japan, from before Buddhist temple architecture came over from the mainland.

The halls you see were built in 1810. For centuries before that, they were taken down and rebuilt every twenty years, the way the shrine at Ise still is. Here the custom faded away in the civil wars of the sixteenth century, and was finally given up in the early eighteen hundreds.

The buildings are only two hundred years old, but the design is far older, kept alive by being copied, carefully, over and over again. In Japan, very often, it's the form that's ancient, not the wood.

*[beat]*

Before you leave, find the great camphor tree in the grounds. It's over a thousand years old. And when you go, catch the little Hankai tram from the stop by the gate. It's Osaka's last surviving streetcar line, and it rattles north towards Tennoji.

## TTS-safe version

See `23_sumiyoshi_taisha_tts-safe.txt`. Spoken title: **Soomee yoshee Tye shah**.

## Respellings used

| Written | Spoken |
|---|---|
| Hankai | Hahn kye |
| Ise | Eesay |
| Jingu | Jeengoo |
| Sorihashi | Soree hahshee |
| Sumiyoshi | Soomee yoshee |
| Sumiyoshi Taisha | Soomee yoshee Tye shah |
| Sumiyoshi-zukuri | Soomee yoshee zookoo ree |
| Tennoji | Ten noh jee |

## Primary sources read before writing

- https://www.sumiyoshitaisha.net/ (official site)
- https://www.city.osaka.lg.jp/kyoiku/cmsfiles/contents/0000674/674603/14.pdf
- https://online.bunka.go.jp/index.php/heritages/detail/147291
