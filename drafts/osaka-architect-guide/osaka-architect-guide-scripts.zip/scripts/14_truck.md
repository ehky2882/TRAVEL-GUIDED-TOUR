# 14 · TRUCK

**Category:** Shop · **Coordinates (WGS-84):** 34.717653, 135.562894 · **Length:** 327 words (about 131 s at 150 wpm)

## Script (clean)

They only sell their furniture in one place, and this is it. If you want a sofa from TRUCK, you come to a quiet residential street in Asahi ward.

Ahead of you, a low group of brick buildings among trees, with a workshop, a shop and, right by it, a café. There's no shopping street here, no neon. Just a furniture maker's yard, built from scratch.

TRUCK is two people. Tokuhiko Kise grew up in Osaka, learned furniture making in Nagano and went independent at twenty-three. Hiromi Karatsu studied textile design at the Osaka University of Arts and became an illustrator. In 1996 they bought an old building in Tamatsukuri and turned it into a shop, a workshop and their home, all in one. TRUCK opened in January 1997.

In 2009 they moved everything here, to a site they built over about two and a half years, from buying the land to planting the trees and laying the brick walls. Shop, workshop and home came along. So did the leather studio, which turns the offcuts from TRUCK sofas into small hand-stitched things.

Have a look at the wood if you go in. American white oak and Japanese oak, chosen for their knots, cracks and rough grain rather than despite them. Every piece is made by hand in the workshop on site, and they build and live with prototypes for a long time before they sell anything.

The interesting bit is this. They say they make furniture they want for themselves, regardless of trends, to be used for a lifetime. Don't worry about scratches, they say, use it with love. That's a philosophy that sits very badly with modern retail. It's exactly why people make the journey out here.

*[beat]*

Check the days before you come: it's closed on Tuesdays and Wednesdays. And stop at Bird, the café TRUCK opened when it moved here. You'll be eating at TRUCK tables on TRUCK chairs, which is the best showroom there is.

## TTS-safe version

See `14_truck_tts-safe.txt`. Spoken title: **Truck**.

## Respellings used

| Written | Spoken |
|---|---|
| Asahi | Ahsahee |
| Hiromi Karatsu | Heeroh mee Kahrah tsoo |
| Nagano | Nahgahnoh |
| TRUCK | Truck |
| Tamatsukuri | Tahmah tsookooree |
| Tokuhiko Kise | Toh koo heekoh Keesay |

## Primary sources read before writing

- https://truck-furniture.co.jp/en/about/ (official site)
- https://www.shift.jp.org/guide/?p=38662
- https://rurubu.jp/andmore/article/8364
