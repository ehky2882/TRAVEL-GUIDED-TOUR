# 01 · Zentis Osaka

**Category:** Stay · **Coordinates (WGS-84):** 34.695778, 135.496384 · **Length:** 359 words (about 144 s at 150 wpm)

## Script (clean)

It's a business district by the river, all office towers, and the hotel that opened here in July 2020 decided to be about as unlike an office as it possibly could.

Stand on the pavement outside the entrance on Dojimahama, with the street behind you. In front of you is a building of dark brick laid in a strict grid, sixteen storeys of it, and at street level a small garden: a Japanese maple and a cherry tree where most of its neighbours would put a revolving door.

Start with that grid. The outside was done by Kajima Design, and the brief was to fit in with the offices around it while making room for the greenery. So the frame looks almost corporate from a distance, and then it softens the closer you get. Brick, rather than glass, is the tell.

Inside is the work of the British designer Tara Bernerd, and she treated it like a converted warehouse that happens to be brand new. Exposed brick, timber beams, heavy ironwork, a staircase of blue limestone, and tall black-framed Crittall windows looking onto the garden. A fireplace opens on two sides, so the lounge and the garden terrace share the same fire.

Have a look at the details if you go in. The bedside tables are Shigaraki pottery, from Shiga, just across the mountains. The charcoal brushwork over every bed is by an Osaka artist, Masami Ehara. Even the room plans were drawn up like a bento box, everything in its compartment.

And here's the thing. This was the very first hotel under the Zentis name, the new label from the group that runs the Palace Hotel in Tokyo, and they chose a street of offices to launch it. It works because it doesn't pretend the offices aren't there. It just gives you a living room in the middle of them.

*[beat]*

If you fancy a drink, the restaurant and bar, Upstairz, is on the second floor, with a covered terrace of its own. Or turn round and walk a couple of blocks north into Kitashinchi, Osaka's grown-up bar district, where the evenings start rather later than you'd expect.

## TTS-safe version

See `01_zentis_osaka_tts-safe.txt`. Spoken title: **Zentiss Osaka**.

## Respellings used

| Written | Spoken |
|---|---|
| Crittall | Krittle |
| Dojimahama | Dohjeemah hahmah |
| Kajima | Kahjeemah |
| Kitashinchi | Keetah sheenchee |
| Masami Ehara | Mahsahmee Ehhahrah |
| Shiga | Sheegah |
| Shigaraki | Sheegah rahkee |
| Upstairz | Upstairs |
| Zentis | Zentiss |

## Primary sources read before writing

- https://zentishotels.com/en/osaka/archive/202011103599 (Zentis press release, 10 Nov 2020)
- https://www.design-anthology.com/story/zentis-osaka
