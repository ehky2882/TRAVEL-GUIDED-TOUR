# Udaan Park

**Udaipur, India** · tour 24 of 24 · slug `udaan-park-udaipur` · ~295 words (~2.0 min)

**Vantage / pin:** Swaroop Sagar, Ambamata — `24.590109, 73.683606` ([Google Maps](https://www.google.com/maps/place/Udaan+Park/@24.5901086,73.6810313,17z/data=!4m14!1m7!3m6!1s0x3967e5ee09659b69:0x1a29d6629197d348!2sUdaan+Park!8m2!3d24.5901086!4d73.6836062!16s%2Fg%2F11rqz8kr85!3m5!1s0x3967e5ee09659b69:0x1a29d6629197d348!8m2!3d24.5901086!4d73.6836062!16s%2Fg%2F11rqz8kr85))

---

Look up. Above the entrance to this little park, tens of thousands of birds are frozen in mid-flight.

You're on the western bank of Swaroop Sagar, one of Udaipur's chain of lakes, at the gate of Udaan Park. Over your head is a canopy of small, life-size handmade birds, strung between branching steel frames that look like trees. Below you, a path winds down over the rocks to the water.

Start with the canopy. The architects, Studio Saar, took the idea from a starling murmuration: those great swirling clouds of birds that gather over lakes and fields at dusk. Starlings come here in winter, so the canopy is a portrait of the park's own visitors. It also gives shade and a place for gatherings, which is why the park has become so popular for parties.

Then the path down. Before this redesign, the park was run-down and hard to get into, perched on a rocky outcrop. Now an accessible route leads from the street right down to the lakeside, past play areas and lookouts. Much of it is made from salvage: old tyres turned into planters, swings and tunnels, and reclaimed steel reinforcing bar bent into the gates and railings.

*[beat]*

And here's the thing worth knowing. Udaipur has very little public green space. By one measure, about two square metres per person, against a recommended nine. Udaan was the first park revived under a charity's campaign to plant a million trees across the city. The planting here was chosen for the birds: native trees whose fruit lasts into the dry season.

Before you leave, walk down to the water's edge and look out across the lake. In winter you might count ducks, geese, egrets, kingfishers and cormorants, all from one bench.

---

**Primary sources read before writing:**
- https://architecturehunter.com/guide/udaipur-india/ (Studio Saar's guide entry)
- https://www.studiosaar.design/practice/udaan-park
- https://architecturetoday.co.uk/udaan-play-park-by-studio-saar/
- https://www.archdaily.com/1006490/udaan-park-studio-saar
