# Ganesh Emporium

**Udaipur, India** · tour 15 of 24 · slug `ganesh-emporium-udaipur` · ~271 words (~1.8 min)

**Vantage / pin:** City Palace Rd, Old City — `24.578709, 73.683884` ([Google Maps](https://www.google.com/maps/place/Ganesh+Emporium+(Vipulshahbags)/@24.5787084,73.6790135,17z/data=!4m14!1m7!3m6!1s0x3967e5643021b8db:0x815deb949bb22a91!2sGanesh+Emporium+(Vipulshahbags)!8m2!3d24.5787085!4d73.6838844!16s%2Fg%2F11j2s7v857!3m5!1s0x3967e5643021b8db:0x815deb949bb22a91!8m2!3d24.5787085!4d73.6838844!16s%2Fg%2F11j2s7v857))

---

Think of it as a department store hidden inside an old haveli. It's a city mansion of archways and courtyards, packed from floor to ceiling with fabric.

You're on City Palace Road, the busy street that runs between the Jagdish Temple and the gates of the City Palace. Ganesh Emporium is the old house on the street, three storeys high. The shopfront gives very little away.

Look up, rather than at the stock, for a moment. The guide that sent you here dates the building to the seventeenth century, and says it has been heavily restored. You can see it in the bones: the grand archways, the high ceilings, the windows set with little mirrors, and the open courtyards that let light down through the middle of the house. Havelis were built inward-looking, around those courtyards, for privacy and to stay cool.

Then the stock. This is where people come for textiles: block prints, embroidery, quilts and fabric by the metre, alongside bags and carved wood. One well-known travel guide passes on a useful tip. The tailors here can make you a tunic to measure in a couple of hours.

*[beat]*

The interesting bit is how naturally the building takes to this. A haveli was always a place where a family's wealth was stored and shown off: textiles, jewellery and fine things kept in chests round the courtyard. Turning one into a shop for exactly those goods isn't really a change of use at all.

Leave yourself an hour, then walk two minutes up to the Jagdish Temple. Its carved stone is the perfect counterpoint to all that cloth.

---

**Primary sources read before writing:**
- https://architecturehunter.com/guide/udaipur-india/ (Studio Saar's guide entry)
- https://indagare.com/shop/ganesh-handicraft-emporium
