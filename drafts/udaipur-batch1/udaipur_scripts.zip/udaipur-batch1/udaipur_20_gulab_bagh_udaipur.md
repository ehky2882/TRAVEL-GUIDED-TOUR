# Gulab Bagh

**Udaipur, India** · tour 20 of 24 · slug `gulab-bagh-udaipur` · ~295 words (~2.0 min)

**Vantage / pin:** Gulab Bagh Rd — `24.572175, 73.692746` ([Google Maps](https://www.google.com/maps/place/Gulab+Bagh/@24.5721752,73.6901706,17z/data=!4m14!1m7!3m6!1s0x3967e5ab8eb06ef9:0x9740323b2c786116!2sGulab+Bagh!8m2!3d24.5721752!4d73.6927455!16s%2Fg%2F11fr4bwdpz!3m5!1s0x3967e5ab8eb06ef9:0x9740323b2c786116!8m2!3d24.5721752!4d73.6927455!16s%2Fg%2F11fr4bwdpz))

---

Gulab means rose, and bagh means garden. So this is the rose garden, although these days it feels more like a jungle that someone has very kindly put paths through.

You're on Gulab Bagh Road, at one of the garden's gates, just south-east of the City Palace. In front of you are tall old trees, shade, and paths heading off in several directions. Early in the morning you'll share them with walkers, joggers and a good many birds.

Its other name is Sajjan Niwas Garden, after Maharana Sajjan Singh, who had it laid out in the eighteen-eighties. In eighteen eighty-two a horticulturist from Madras, T. H. Story, was brought in to stock it. He planted fruit trees and medicinal plants and labelled every one with its name in Hindi, in English and in botany's own Latin. He stayed until nineteen-twenty. The garden even had its own zoo, one of the oldest in the country.

Somewhere in the trees is the Victoria Hall. It opened in eighteen-ninety as a museum, the first in Rajasthan. Today it's the Saraswati Bhawan Library, with more than thirty thousand books, some manuscripts among them. The building still has the formal look of a Victorian museum.

*[beat]*

What's worth knowing is that this was a royal garden made for public use. It was a ruler's idea of improvement, with plants that were labelled so people could learn their names. A hundred and forty years on, it's still doing that job. You'll see people from every corner of the city walking here every morning.

If walking isn't on the cards, look out for the little toy train. It loops round the garden past the rose beds, the library and the old museum, and it's quite unashamedly charming.

---

**Primary sources read before writing:**
- https://architecturehunter.com/guide/udaipur-india/ (Studio Saar's guide entry)
- https://en.wikipedia.org/wiki/Sajjan_Niwas_Garden
