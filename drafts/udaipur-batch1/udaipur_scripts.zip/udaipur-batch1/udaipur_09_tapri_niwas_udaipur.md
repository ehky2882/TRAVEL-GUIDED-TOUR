# Tapri Niwas

**Udaipur, India** · tour 09 of 24 · slug `tapri-niwas-udaipur` · ~263 words (~1.8 min)

**Vantage / pin:** New Fatehpura, Panchwati — `24.602514, 73.689970` ([Google Maps](https://www.google.com/maps/place/Tapri+Niwas%C2%AE/@24.6025142,73.6873951,17z/data=!3m1!4b1!4m6!3m5!1s0x3967e582183f02df:0x1b79202dd63e67ec!8m2!3d24.6025142!4d73.68997!16s%2Fg%2F11sf521bbh))

---

A tapri is the humblest thing in Indian street life: a roadside chai stall, often just a stove under a tarpaulin. This place took the name and built a house round it.

You're in New Fatehpura, on the main road near St Mary's School. Tapri Niwas, niwas meaning a home or residence, is the building with people spilling out of it, cups in hand.

Look at what's being drunk around you. Chai, made simply, the way it would be at home. The company's founders have said that's the whole secret: simple recipes, plain good ingredients, and nothing that needs a chef's attention to get right. The food follows the same rule. Think home-style snacks rather than a menu that's trying to impress you.

The story behind it is rather charming. Tapri started in Jaipur in two thousand and ten as an MBA project, and the founders cheerfully admit it failed academically. It worked as a business instead. Tapri Niwas was its first outlet in Udaipur.

There's one more thing to notice. Tapri has made a point of hiring staff who are deaf or speech-impaired, and putting them out front, serving, rather than tucking them away in the kitchen. If someone signs your order back to you, that's why.

*[beat]*

And here's the thing. A chai stall was always really about the conversation. The tea was just the excuse to stop. Tapri built a business by taking that seriously.

Before you go, have a look in the shop on the same site. It's called Ladu, and it sells goods from small makers.

---

**Primary sources read before writing:**
- https://architecturehunter.com/guide/udaipur-india/ (Studio Saar's guide entry)
- https://allaboutjaipur.com/tapris-founders-share-their-insights-on-why-tapri-is-still-the-it-place-for-chai-in-jaipur/8377/
- https://yappe.in/rajasthan/udaipur/tapri-niwas-r/518876
- https://www.tripadvisor.com/--d27782195.html
