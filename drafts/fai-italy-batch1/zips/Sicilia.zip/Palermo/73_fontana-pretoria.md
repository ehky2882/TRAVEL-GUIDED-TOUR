# Fontana Pretoria, Palermo

*356 words, about 142 seconds at a natural pace.*

## Clean script

This fountain was made in Florence, taken apart into six hundred and forty-four pieces, shipped to Palermo, and put back together. The people of Palermo still call it the Fountain of Shame.

You're in Piazza Pretoria, a few steps from the Quattro Canti, the crossroads at the centre of old Palermo. The fountain fills almost the whole square: tier on tier of marble basins, rails, steps and statues, with gods, river figures and animal heads spouting water.

It was carved in Florence in fifteen fifty-four by the sculptor Francesco Camilliani, for the garden of a villa belonging to a member of the Toledo family, the brother of the Duchess of Florence. In fifteen seventy-three he sold it to the city of Palermo. It arrived in May fifteen seventy-four in six hundred and forty-four pieces, a hundred and twelve of them packed into sixty-nine crates. Some were broken on the way.

Putting it back together took seven years. Camilliani's son Camillo did it, with the help of the sculptor Michelangelo Naccherino, and to make room, houses around the square were pulled down.

So, the shame. One reason was the cost, which kept rising. The other, the more famous one, is that so many of the figures are naked, and the nuns of the convent of Santa Caterina, right on the corner of the square, were said to be thoroughly scandalised.

[beat]

Have a look at the four groups around the fountain. They were renamed after the rivers of Palermo, among them the Oreto and the Papireto. And at the top, the Genius of Palermo, the city's protector, who started life in Florence as a Bacchus.

In seventeen thirty-seven an iron railing went round it to stop vandals, and it's been restored several times since, most recently between nineteen ninety-eight and two thousand and three.

When you've had your fill, look at what surrounds it. The town hall is on one side, the church of Santa Caterina on the other, and down the steps is the church of San Giuseppe dei Teatini. It's one of the great stage sets of the Baroque, and the fountain is the leading lady.

## TTS-safe script

**fon tah na preh tor ee ah, pa lair mo**

This fountain was made in Florence, taken apart into six hundred and forty four pieces, shipped to pa lair mo, and put back together. The people of pa lair mo still call it the Fountain of Shame.

You're in pyat sa preh tor ee ah, a few steps from the kwat tro kan tee, the crossroads at the centre of old pa lair mo. The fountain fills almost the whole square: tier on tier of marble basins, rails, steps and statues, with gods, river figures and animal heads spouting water.

It was carved in Florence in fifteen fifty four by the sculptor fran ches ko ka mee lee ah nee, for the garden of a villa belonging to a member of the to leh doh family, the brother of the Duchess of Florence. In fifteen seventy three he sold it to the city of pa lair mo. It arrived in May fifteen seventy four in six hundred and forty four pieces, a hundred and twelve of them packed into sixty nine crates. Some were broken on the way.

Putting it back together took seven years. ka mee lee ah nee's son ka mee lo did it, with the help of the sculptor mee kel an jeh lo nak keh ree no, and to make room, houses around the square were pulled down.

So, the shame. One reason was the cost, which kept rising. The other, the more famous one, is that so many of the figures are naked, and the nuns of the convent of santa ka teh ree na, right on the corner of the square, were said to be thoroughly scandalised.

Have a look at the four groups around the fountain. They were renamed after the rivers of pa lair mo, among them the oh reh toh and the pa pee reh toh. And at the top, the Genius of pa lair mo, the city's protector, who started life in Florence as a back us.

In seventeen thirty seven an iron railing went round it to stop vandals, and it's been restored several times since, most recently between nineteen ninety eight and two thousand and three.

When you've had your fill, look at what surrounds it. The town hall is on one side, the church of santa ka teh ree na on the other, and down the steps is the church of san joo sep pay day teh ah tee nee. It's one of the great stage sets of the ba rock, and the fountain is the leading lady.

## Respellings

| Written | Spoken as |
|---|---|
| Fontana Pretoria | fon tah na preh tor ee ah |
| Palermo | pa lair mo |
| Piazza Pretoria | pyat sa preh tor ee ah |
| Quattro Canti | kwat tro kan tee |
| Francesco Camilliani | fran ches ko ka mee lee ah nee |
| Camilliani | ka mee lee ah nee |
| Toledo | to leh doh |
| Camillo | ka mee lo |
| Michelangelo Naccherino | mee kel an jeh lo nak keh ree no |
| Santa Caterina | santa ka teh ree na |
| Oreto | oh reh toh |
| Papireto | pa pee reh toh |
| Bacchus | back us |
| San Giuseppe dei Teatini | san joo sep pay day teh ah tee nee |
| Baroque | ba rock |

## Sources read

- https://it.wikipedia.org/wiki/Fontana_Pretoria
- https://it.wikipedia.org/wiki/Piazza_Pretoria

## Fact-check notes

- Commissioner: Wikipedia names Pedro Álvarez de Toledo as commissioner and Luigi (his son, brother of Eleonora di Toledo) as the garden owner and seller. The script says 'a member of the Toledo family, the brother of the Duchess of Florence'.
- Sale in 1573 (the Fontana lead says 1581, an inconsistency).
- 644 pieces, 112 in 69 crates, arrived 26 May 1574.
- The statue count in Palermo is unverified, so none is given. Only two river names are verified verbatim.
- The 'town hall' is Palazzo Pretorio (Palazzo delle Aquile isn't named in the sources).
- 'Stage set… leading lady' is the narrator's flourish.
