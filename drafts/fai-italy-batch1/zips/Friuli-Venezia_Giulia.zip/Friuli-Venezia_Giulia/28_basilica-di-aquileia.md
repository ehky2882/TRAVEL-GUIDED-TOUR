# Basilica di Aquileia

*313 words, about 125 seconds at a natural pace.*

## Clean script

Under your feet is a floor laid not long after Christianity stopped being illegal. It's the largest early Christian mosaic in the western world.

Step inside the basilica and look down. A carpet of mosaic stretches almost the whole length of the church: fish, birds, shepherds, inscriptions, and a great deal of sea.

It was laid by Bishop Theodore in the years just after three thirteen, when the Emperor Constantine allowed Christians to worship openly. It covers more than seven hundred and sixty square metres. For centuries nobody could see it at all. It was only brought back to light between nineteen oh nine and nineteen twelve.

Have a look for three things. First, Jonah, a story told in episodes: thrown to a sea monster, swallowed, spat out again, and finally resting under a vine. Then the Good Shepherd, with a sheep across his shoulders. And then a strange little fight between a cockerel and a tortoise. The cockerel, crowing at dawn, has long been read as the light of Christ. The tortoise, in this reading, stands for darkness, and its name in Greek was thought to come from Tartarus, the underworld.

Look in the fishing scene, too, for Theodore's own inscription. It begins Theodore, you are blessed, and it thanks him for building the church.

[beat]

Here's what I find so moving. These are some of the first Christian pictures anyone made in public, and they're not grand or solemn. They're cheerful. Fish and birds and a man getting swallowed by a whale.

The church above you came later. It was rebuilt in the Romanesque style and consecrated by Patriarch Poppo in ten thirty-one, and he raised the great bell tower outside, more than seventy metres tall.

Before you go, find the Crypt of the Excavations. There's more fourth-century mosaic down there, from Theodore's northern hall, and it's quieter, and rather more mysterious.

## TTS-safe script

**Basilica di ah kwee lay ah**

Under your feet is a floor laid not long after Christianity stopped being illegal. It's the largest early Christian mosaic in the western world.

Step inside the basilica and look down. A carpet of mosaic stretches almost the whole length of the church: fish, birds, shepherds, inscriptions, and a great deal of sea.

It was laid by Bishop thee oh dor in the years just after three thirteen, when the Emperor kon stan tine allowed Christians to worship openly. It covers more than seven hundred and sixty square metres. For centuries nobody could see it at all. It was only brought back to light between nineteen oh nine and nineteen twelve.

Have a look for three things. First, Jonah, a story told in episodes: thrown to a sea monster, swallowed, spat out again, and finally resting under a vine. Then the Good Shepherd, with a sheep across his shoulders. And then a strange little fight between a cockerel and a tortoise. The cockerel, crowing at dawn, has long been read as the light of Christ. The tortoise, in this reading, stands for darkness, and its name in Greek was thought to come from tar ta rus, the underworld.

Look in the fishing scene, too, for thee oh dor's own inscription. It begins thee oh dor, you are blessed, and it thanks him for building the church.

Here's what I find so moving. These are some of the first Christian pictures anyone made in public, and they're not grand or solemn. They're cheerful. Fish and birds and a man getting swallowed by a whale.

The church above you came later. It was rebuilt in the ro man esk style and consecrated by patriarch pop poh in ten thirty one, and he raised the great bell tower outside, more than seventy metres tall.

Before you go, find the Crypt of the Excavations. There's more fourth century mosaic down there, from thee oh dor's northern hall, and it's quieter, and rather more mysterious.

## Respellings

| Written | Spoken as |
|---|---|
| Aquileia | ah kwee lay ah |
| Theodore | thee oh dor |
| Constantine | kon stan tine |
| Tartarus | tar ta rus |
| Patriarch Poppo | patriarch pop poh |
| Poppo | pop poh |
| Romanesque | ro man esk |

## Sources read

- https://www.basilicadiaquileia.it/
- https://www.basilicadiaquileia.it/it/basilica/storia
- https://www.basilicadiaquileia.it/it/15767/orari
- https://www.basilicadiaquileia.it/it/15451/visite-individuali
- https://it.wikipedia.org/wiki/Basilica_di_Santa_Maria_Assunta_(Aquileia)

## Fact-check notes

- 'Largest early Christian mosaic in the western world, 760 m²' is the official site's claim.
- The cockerel and tortoise interpretation and the Tartarus etymology are from Wikipedia and are framed as interpretation.
- Bell tower 'over 70 m' (Wikipedia verbatim); 73 m is unverified.
- Aquileia's Roman history isn't covered by the sources read, so it is left out.
