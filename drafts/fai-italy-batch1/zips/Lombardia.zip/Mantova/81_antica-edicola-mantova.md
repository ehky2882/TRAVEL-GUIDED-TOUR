# Antica Edicola dei Giornali, Mantua

*354 words, about 142 seconds at a natural pace.*

## Clean script

This may well be one of the prettiest newsstands in Italy, and it was moved here because it was getting in the way of a church.

You're in Piazza Canossa, in the old centre of Mantua. In front of you, standing on its own, is a small eight-sided kiosk of iron, wood and glass, on a low stone base, with pointed windows all the way round and a little metal spire on top, like a lantern that's wandered in from a Gothic cathedral.

People often call it Liberty, Italy's word for Art Nouveau, but have a look at those windows. They're paired pointed arches, which makes it neo-Gothic, a nineteenth-century idea of the Middle Ages rather than a twentieth-century one.

In eighteen eighty-two the town gave a Mantuan called Ulisse Sicola permission to open a newspaper kiosk in the square in front of Sant'Andrea, the great church by Leon Battista Alberti. In nineteen twenty-five he was asked to move it here, so as not to interfere, in the words of the time, with the triumphal architecture of the basilica. I rather like that. The newspaper man was told he was spoiling the view.

It very nearly didn't survive. In nineteen eleven its roof was replaced with a cap of concrete that blocked the little upper windows, and by the late twentieth century it was in a sorry state. It was protected in nineteen ninety-one, bought the following year after a public appeal, and put back the way it was meant to look. For a while it sold flowers instead of newspapers.

[beat]

What's worth knowing, standing here, is how much care has gone into something so small. In twenty twenty-three it was restored again, piece by piece, removing the rust and replacing only what couldn't be saved. Now it's lit up as a tiny gallery, with exhibitions of local photographers. A lantern for the city, after all.

From here it's a short walk to Piazza Mantegna and the front of Sant'Andrea. Stand there for a moment and picture the kiosk in front of that enormous arch. You can see why somebody asked it to move.

## TTS-safe script

**anteeka edeekola day jornahlee, mantyooa**

This may well be one of the prettiest newsstands in Italy, and it was moved here because it was getting in the way of a church.

You're in pyatsa kanossa, in the old centre of mantyooa. In front of you, standing on its own, is a small eight sided kiosk of iron, wood and glass, on a low stone base, with pointed windows all the way round and a little metal spire on top, like a lantern that's wandered in from a Gothic cathedral.

People often call it liberty, Italy's word for Art Nouveau, but have a look at those windows. They're paired pointed arches, which makes it neo Gothic, a nineteenth century idea of the Middle Ages rather than a twentieth century one.

In eighteen eighty two the town gave a mantyooan called ooleesay seekola permission to open a newspaper kiosk in the square in front of santandraya, the great church by layon batteesta albairtee. In nineteen twenty five he was asked to move it here, so as not to interfere, in the words of the time, with the triumphal architecture of the basilica. I rather like that. The newspaper man was told he was spoiling the view.

It very nearly didn't survive. In nineteen eleven its roof was replaced with a cap of concrete that blocked the little upper windows, and by the late twentieth century it was in a sorry state. It was protected in nineteen ninety one, bought the following year after a public appeal, and put back the way it was meant to look. For a while it sold flowers instead of newspapers.

What's worth knowing, standing here, is how much care has gone into something so small. In twenty twenty three it was restored again, piece by piece, removing the rust and replacing only what couldn't be saved. Now it's lit up as a tiny gallery, with exhibitions of local photographers. A lantern for the city, after all.

From here it's a short walk to pyatsa mantenya and the front of santandraya. Stand there for a moment and picture the kiosk in front of that enormous arch. You can see why somebody asked it to move.

## Respellings

| Written | Spoken as |
|---|---|
| Antica Edicola dei Giornali | anteeka edeekola day jornahlee |
| Mantua | mantyooa |
| Piazza Canossa | pyatsa kanossa |
| Ulisse Sicola | ooleesay seekola |
| Sant'Andrea | santandraya |
| Leon Battista Alberti | layon batteesta albairtee |
| Piazza Mantegna | pyatsa mantenya |
| Liberty | liberty |

## Sources read

- https://fondoambiente.it/antica-edicola-dei-giornali-eng
- https://fondoambiente.it/news/il-restauro-dellantica-edicola-di-mantova-una-lanterna-della-cultura
- https://fondoambiente.it/luoghi/antica-edicola-dei-giornali

## Fact-check notes

- Owner named it 'Antica Edicola Liberty'; the official name is Antica Edicola dei Giornali, and the primary sources describe its style as neo-Gothic. The script says both.
- Original site: 'Piazza Sant'Andrea' (English page) and 'Piazza Mantegna' (2023 news) are the same square in front of the basilica; the script says 'the square in front of Sant'Andrea' and later 'Piazza Mantegna'.
- 1911 concrete cap, protection on 18 October 1991, purchase 1992 after a public appeal, 2023 restoration and photo exhibitions: FAI news (2023). The buyer is not named, per owner instruction.
- Owner's coordinate reverse-geocodes to 7 Piazza Matilde Canossa: correct.
