# Monte Fontana Secca

*362 words, about 145 seconds at a natural pace.*

## Clean script

In November nineteen seventeen, the front line of the First World War came up this mountain. A century later, the cows are coming back.

You're on the high pastures of the Monte Grappa massif, between the peaks of Monte Valderoa, Monte Solarolo and Monte Fontana Secca. Look around for the low stone buildings of the malga, the summer dairy farm, and then look out. On a clear day the view runs down the valley of the Piave all the way to the Venetian lagoon.

These hundred and fifty hectares of meadow and woodland were given away in twenty fifteen by Bruno and Liliana Collavo, to be looked after and opened to visitors, in memory of their parents, Aldo Collavo and Erminia Secco.

But first, the war. After the defeat at Caporetto in the autumn of nineteen seventeen, Italy's line fell back to the Grappa and the Piave. On the twenty-first and twenty-second of November, the summit here was taken by the Austro-German army, after it had been defended by the Alpine troops of the Vallecamonica battalion. If you walk the paths you'll still find trenches, tunnels and memorial stones. The ridge route that links them is called the Alta Via degli Eroi, the High Way of the Heroes, and it leads to the great war memorial on the summit of Cima Grappa.

[beat]

What's happening here is quietly ambitious. Not preserving a ruin, but bringing a working mountain farm back to life, with no mains water and no mains electricity. The old herdsman's house has been restored and opened as a place to tell the story of the mountain, with a film narrated by the actress Michela Cescon. The old stalls have been rebuilt to welcome visitors. And the pastures are meant for the Burlina, a cow found nowhere but the Veneto, and close to disappearing.

Up here the dairy makes the local mountain cheeses, Morlacco and Bastardo.

Before you come, check what's open, because the work is still going on. And then walk a stretch of the Alta Via degli Eroi. It's an extraordinary thing, to stand in a meadow full of cows and see a line of trenches running through it.

## TTS-safe script

**mon tay fon tah na sek ka**

In November nineteen seventeen, the front line of the First World War came up this mountain. A century later, the cows are coming back.

You're on the high pastures of the mon tay grap pa massif, between the peaks of mon tay val deh ro ah, mon tay so la ro lo and mon tay fon tah na sek ka. Look around for the low stone buildings of the mal ga, the summer dairy farm, and then look out. On a clear day the view runs down the valley of the pyah veh all the way to the Venetian lagoon.

These hundred and fifty hectares of meadow and woodland were given away in twenty fifteen by broo no and lee lee ah na kol lah vo, to be looked after and opened to visitors, in memory of their parents, al doh kol lah vo and air mee nee ah sek ko.

But first, the war. After the defeat at ka po ret toh in the autumn of nineteen seventeen, Italy's line fell back to the Grappa and the pyah veh. On the twenty first and twenty second of November, the summit here was taken by the Austro German army, after it had been defended by the Alpine troops of the val leh ka mo nee ka battalion. If you walk the paths you'll still find trenches, tunnels and memorial stones. The ridge route that links them is called the al ta vee ah del yee eh roy, the High Way of the Heroes, and it leads to the great war memorial on the summit of chee ma grap pa.

What's happening here is quietly ambitious. Not preserving a ruin, but bringing a working mountain farm back to life, with no mains water and no mains electricity. The old herdsman's house has been restored and opened as a place to tell the story of the mountain, with a film narrated by the actress mee keh la chess kon. The old stalls have been rebuilt to welcome visitors. And the pastures are meant for the boor lee na, a cow found nowhere but the ven eh toh, and close to disappearing.

Up here the dairy makes the local mountain cheeses, mor lak ko and bas tar doh.

Before you come, check what's open, because the work is still going on. And then walk a stretch of the al ta vee ah del yee eh roy. It's an extraordinary thing, to stand in a meadow full of cows and see a line of trenches running through it.

## Respellings

| Written | Spoken as |
|---|---|
| Monte Fontana Secca | mon tay fon tah na sek ka |
| Monte Grappa | mon tay grap pa |
| Monte Valderoa | mon tay val deh ro ah |
| Monte Solarolo | mon tay so la ro lo |
| malga | mal ga |
| Piave | pyah veh |
| Bruno and Liliana Collavo | broo no and lee lee ah na kol lah vo |
| Aldo Collavo | al doh kol lah vo |
| Erminia Secco | air mee nee ah sek ko |
| Caporetto | ka po ret toh |
| Vallecamonica | val leh ka mo nee ka |
| Alta Via degli Eroi | al ta vee ah del yee eh roy |
| Cima Grappa | chee ma grap pa |
| Michela Cescon | mee keh la chess kon |
| Burlina | boor lee na |
| Veneto | ven eh toh |
| Morlacco | mor lak ko |
| Bastardo | bas tar doh |

## Sources read

- https://fondoambiente.it/luoghi/monte-fontana-secca-e-col-de-spadarot
- https://fondoambiente.it/news/il-fai-apre-al-pubblico-la-malga-di-monte-fontana-secca
- https://fondoambiente.it/news/monte-fontana-secca-il-progetto-di-restauro-e-valorizzazione
- https://www.fondoambiente.it/news/monte-fontana-secca-nuova-vita-al-compendio-agricolo-pastorale

## Fact-check notes

- Donation year: 2015 in the header and news items; the FAI body text says 2014. The script uses 2015.
- 'Burlina found nowhere but the Veneto' paraphrases FAI's 'only native Veneto breed'.
- Opening status is uncertain (the Stallone was due summer 2026), so the script tells listeners to check.
- The shortlist coordinates were updated to FAI's map link: 45.92272, 11.80777.
- 'Defended by … before it was taken' compresses FAI's account; check the wording.
