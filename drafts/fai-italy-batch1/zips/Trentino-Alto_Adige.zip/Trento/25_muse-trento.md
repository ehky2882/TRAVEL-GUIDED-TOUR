# MUSE, Museo delle Scienze

*323 words, about 129 seconds at a natural pace.*

## Clean script

Look at the roofline and you'll see mountains. That's not an accident.

From the lawn in front of the museum, take in the whole building: long and low, with a jagged, sharply pointed roof that rises and falls like a ridge of peaks. The architect was Renzo Piano, and the outline is meant to recall the mountains of Trentino, and especially the Dolomites.

It opened in July twenty thirteen, on the site of the old Michelin factory, and Piano designed the new neighbourhood around it too, Le Albere. A tyre works became a science museum, which feels about right for a city that's always had to make the most of a narrow valley floor.

Inside, the whole museum is built on one idea, a mountain you explore from the top down. Start on the fourth floor, with the high peaks and a glacier made of real ice. Then work your way down through alpine nature, geology and the history of the people of the Alps, all the way to the lowest level, where the story becomes the history of life itself. At the western end there's a tropical greenhouse, six hundred square metres of mountain rainforest.

And running through the middle of it all is the Big Void, a tall open space that links every floor. Hanging in it are animals, as if they're flying or leaping across the gap, and the complete skeleton of a fin whale that washed up on the coast near Livorno in nineteen ninety-five.

[beat]

What I like about MUSE is that it doesn't ask you to look at science behind glass. It asks you to walk downhill through it. More than five million people have done so since it opened.

Before you start, go right up to the terrace on the fifth floor. From there you can see over Trento and along the Adige valley to the real mountains, and then the building's roof starts to make sense.

## TTS-safe script

**moo zeh, moo zeh oh del leh shen tseh**

Look at the roofline and you'll see mountains. That's not an accident.

From the lawn in front of the museum, take in the whole building: long and low, with a jagged, sharply pointed roof that rises and falls like a ridge of peaks. The architect was ren tso pyah no, and the outline is meant to recall the mountains of tren tee no, and especially the dol oh mites.

It opened in July twenty thirteen, on the site of the old mish lan factory, and Piano designed the new neighbourhood around it too, leh al beh reh. A tyre works became a science museum, which feels about right for a city that's always had to make the most of a narrow valley floor.

Inside, the whole museum is built on one idea, a mountain you explore from the top down. Start on the fourth floor, with the high peaks and a glacier made of real ice. Then work your way down through alpine nature, geology and the history of the people of the Alps, all the way to the lowest level, where the story becomes the history of life itself. At the western end there's a tropical greenhouse, six hundred square metres of mountain rainforest.

And running through the middle of it all is the Big Void, a tall open space that links every floor. Hanging in it are animals, as if they're flying or leaping across the gap, and the complete skeleton of a fin whale that washed up on the coast near lee vor no in nineteen ninety five.

What I like about moo zeh is that it doesn't ask you to look at science behind glass. It asks you to walk downhill through it. More than five million people have done so since it opened.

Before you start, go right up to the terrace on the fifth floor. From there you can see over tren toh and along the ah dee jeh valley to the real mountains, and then the building's roof starts to make sense.

## Respellings

| Written | Spoken as |
|---|---|
| MUSE | moo zeh |
| Museo delle Scienze | moo zeh oh del leh shen tseh |
| Renzo Piano | ren tso pyah no |
| Trentino | tren tee no |
| Dolomites | dol oh mites |
| Michelin | mish lan |
| Le Albere | leh al beh reh |
| Livorno | lee vor no |
| Trento | tren toh |
| Adige | ah dee jeh |

## Sources read

- https://www.muse.it/
- https://www.muse.it/home/scopri-il-museo/
- https://www.muse.it/home/scopri-il-museo/sei-piani-di-meraviglia/
- https://www.muse.it/home/pianifica-la-visita/
- https://it.wikipedia.org/wiki/MUSE_-_Museo_delle_Scienze

## Fact-check notes

- Opening: 27 July 2013 (Wikipedia); the official site says July 2013. The script says July.
- The mountain-profile reading is from Wikipedia; the official site says the building follows 'the metaphor of the mountain'.
- LEED Gold is Wikipedia-only, so it isn't used.
- The fin whale stranded near Livorno in 1995 is from Wikipedia.
- 'Over five million visitors' was reached by the end of 2024 (Wikipedia).
