# La Grande Borne

**Series:** Grands Ensembles · **Place:** La Grande Borne (Grigny / Viry-Châtillon)  
**City:** Grigny, France  
**Coordinates:** 48.652242798164714, 2.375369277186132  
**Length:** 436 words · about 2:48 at a natural pace  
**TTS title:** La Grond Born

## Script (clean)

There's a giant buried in the sand somewhere on this estate. Hold that thought.

You're in La Grande Borne, in Grigny, south of Paris. Around you, low blocks of flats curve and snake across the ground, none of them much more than five storeys high. Somewhere off to one side you may hear the A6 motorway, which runs along one edge of the estate.

The architect was Émile Aillaud, the same man who dressed the towers at Nanterre in clouds. He built this between nineteen sixty-seven and nineteen seventy-one, and it's big: three thousand six hundred and eighty-five homes on about ninety hectares. Many of the first families came from the shanty towns on the edge of Paris, and from streets in the thirteenth arrondissement that were being cleared at the time.

Have a look at the shapes first. Instead of straight slabs lined up in rows, Aillaud gave the estate curves, enclosed courtyards and quarters with names. Labyrinthe, the labyrinth. Méridien, the meridian. Peupleraie, the poplar grove.

Then the colour. The painter Fabio Rieti drew up a scheme for the whole estate, with glass mosaic on the curving blocks and glazed stoneware on the straight ones. Other painters, among them Aillaud's own son Gilles, added murals. Most of those have since been covered over, during repairs in the nineteen eighties.

And then the sculptures, put where children could get at them. Pigeons by François-Xavier Lalanne. A sea serpent. And in the Place de l'Œuf, a figure of Gulliver by Aillaud's daughter, Laurence Rieti: a giant lying half sunk in the sand of a playground, his leg doubling as a slide.

Here's the thing. Most of the big estates of that era were planned from above, for the car and the crane. Aillaud planned this one at the height of someone walking, and ideally someone small. In the late nineteen sixties that was a radical way to think about public housing.

[beat]

It hasn't been easy here since. Unemployment has been high for decades, and a renewal scheme in the two thousands knocked down hundreds of flats. But in two thousand and eight the state gave La Grande Borne its label for twentieth-century heritage, the same day as Aillaud's towers at Nanterre. Both, in their way, were attempts to make public housing feel like somewhere a person might choose to live.

If you've got a few minutes, ask for the Place de l'Œuf and go looking for Gulliver: a head rising out of the sand, and a leg you can slide down. Bring a child if you can. That's who he's for.

## Respellings (used in the TTS-safe version)

| Written | Say it |
|---|---|
| François-Xavier Lalanne | fron swah zav yay la lan |
| Place de l'Œuf | plass duh luff |
| Laurence Rieti | lo ronce ree etty |
| Fabio Rieti | fabby oh ree etty |
| La Grande Borne | la grond born |
| Émile Aillaud | ay meel eye oh |
| Aillaud | eye oh |
| Labyrinthe | la bee rant |
| Méridien | may ree dee an |
| Peupleraie | pupluh ray |
| arrondissement | arron deese mon |
| Gilles | zheel |
| Grigny | green yee |
| A6 motorway | A six motorway |
| Nanterre | non tair |

`[beat]` marks a deliberate pause. The TTS-safe file replaces it with a paragraph break.

## Sources read before writing

- https://fr.wikipedia.org/wiki/La_Grande_Borne
- https://inventaire.iledefrance.fr/illustration/IVR11_20129100024NUC4A
- https://www.centrepompidou.fr/fr/ressources/oeuvre/cbqr8dk
- https://francearchives.gouv.fr/facomponent/c61ba65509ff92ce89d2f67f93d033a962aa1069
