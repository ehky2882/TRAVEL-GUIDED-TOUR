# Les Arènes de Picasso

**Series:** Grands Ensembles · **Place:** Les Arènes de Picasso, place Pablo-Picasso  
**City:** Noisy-le-Grand, France  
**Coordinates:** 48.83902884679481, 2.555522868151227  
**Length:** 367 words · about 2:22 at a natural pace  
**TTS title:** Lay Zarenn duh Picasso

## Script (clean)

The people who live here call those two round buildings the camemberts. Once you've heard that, you can't unhear it.

Place Pablo-Picasso, Noisy-le-Grand. You're in an eight-sided square, enclosed by buildings on every side but the south. On either side of you, east and west, stand two enormous round facades facing each other across the square, each about fifty metres across, and pierced all over with windows.

This was designed by the Spanish architect Manuel Núñez Yanowsky, who had worked alongside Ricardo Bofill. It was commissioned in nineteen eighty-one and opened in nineteen eighty-five, as part of the new town of Marne-la-Vallée: five hundred and forty flats, a nursery, a school and shops, all wrapped round this one square.

Have a look at the two discs first. The architect described the whole complex as an abstract cart that has been tipped over, and those are its wheels. Once you see the wheels, the long buildings between them start to look like the body of the cart lying on its side.

Then think about what he was borrowing. Núñez Yanowsky pointed to Gaudí's Park Güell in Barcelona, to the Pantheon in Rome, and to Boullée's great spherical monument to Isaac Newton, which was never built. That's a lot of history to bring to a housing estate in the eastern suburbs.

And here's the thing. By the early nineteen eighties, the grey slab estates of the post-war years had become a byword for everything wrong with the suburbs. The new towns tried the opposite: theatre, ceremony, a public square as grand as anything in the city centre. This is that idea at its most confident.

[beat]

Film-makers noticed straight away. Billy Ze Kick, released the year this opened, was shot entirely here, and the square has turned up in films and music videos ever since, most recently the horror film Vermines.

If you've got time, walk on to the Espaces d'Abraxas, Ricardo Bofill's housing a short way across Noisy-le-Grand. It's where Terry Gilliam shot parts of Brazil, and seeing the two side by side tells you a great deal about what these architects thought a suburb could be.

## Respellings (used in the TTS-safe version)

| Written | Say it |
|---|---|
| Les Arènes de Picasso | lay zarenn duh picasso |
| Manuel Núñez Yanowsky | manwell noon yeth yanovsky |
| Núñez Yanowsky | noon yeth yanovsky |
| Espaces d'Abraxas | es pass dab rax us |
| Marne-la-Vallée | marn la va lay |
| Noisy-le-Grand | nwah zee luh gron |
| Place Pablo-Picasso | plass pablo picasso |
| Park Güell | park gwell |
| Billy Ze Kick | billy zuh kick |
| Ricardo Bofill | ricardo bo feel |
| Vermines | vair meen |
| Boullée | boo lay |
| Gaudí | gow dee |
| camemberts | camem bears |

`[beat]` marks a deliberate pause. The TTS-safe file replaces it with a paragraph break.

## Sources read before writing

- https://fr.wikipedia.org/wiki/Ar%C3%A8nes_de_Picasso
- https://www.pariszigzag.fr/insolite/arenes-de-picasso-noisy/
- https://divisare.com/projects/332390-manuel-nunez-yanowsky-gili-merin-les-arenes-de-picasso
