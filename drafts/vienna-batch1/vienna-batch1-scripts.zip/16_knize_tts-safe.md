# kuh nee zheh

On the grah ben, Vienna's grandest shopping street, there's a shopfront by adolf lohs that has barely changed in more than a century.

You're on the grah ben, at number thirteen. Find the shopfront with the name kuh nee zheh spelled out above it, in a band of polished dark stone around the door and windows. Turn round and the Plague Column, with its swirling cloud of saints, is behind you in the middle of the street.

The firm was founded in eighteen fifty eight by a Czech tailor, yo zef kuh nee zheh, who made riding clothes, sporting wear and liveries for Vienna's grand households. Between nineteen ten and nineteen thirteen, adolf lohs designed this shop. It has survived almost unaltered, which is rare for any lohs interior, let alone one still doing the job it was built for.

lohs thought ornament belonged to the past, but he never thought luxury did. Look at the way the front is made: plain, dark, beautifully proportioned, the lettering doing almost all of the decoration. Inside, the rooms are lined in wood and feel more like a gentleman's club than a shop.

The client list is a little startling. mar lay neh dee trikh had her stage tailcoats made here. oskar ko kosh ka, Billy Wilder, Josephine Baker and Georgia O'Keeffe are all on it. lohs even designed a second kuh nee zheh shop on the shonz ay lee zay in Paris in the late nineteen twenties.

And the craft continues. The art of making tailcoats to measure is on Austria's list of intangible cultural heritage, and kuh nee zheh is one of the last workshops still doing it by hand, in the master workshop here on the grah ben.

Before you go, walk a few doors along to the grah ben's crossing with kole markt, then look down kole markt to the mikh ah eler plats. The plain building facing the palace gate at the end is lohs's lohs house, the one that so offended the Emperor.
