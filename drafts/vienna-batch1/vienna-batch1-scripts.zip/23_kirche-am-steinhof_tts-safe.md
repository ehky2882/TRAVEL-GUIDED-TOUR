# keer kheh am shtine hofe

This church was designed for patients of a psychiatric hospital, and almost every detail in it was thought through for their sake.

You're on the hill of the bowm gartner her eh, at the top of the grounds of the old shtine hofe hospital, in the west of the city. In front of you is a white church faced in marble slabs, with a gilded dome and two slender towers, each topped by a seated saint. That's the keer kheh am shtine hofe, Otto Wagner's church of Saint Leopold, completed in nineteen hundred and seven.

The hospital around you was built as a whole town for the mentally ill, laid out down the slope below, and the church was its crown. The figures on the towers, by rikh ard looksh, are Saint Leopold and Saint sev er een, two saints with deep roots in Austria. The angels over the entrance are by ot mar shim ko vits, who also made the aluminium figures on Wagner's Post Office Savings Bank.

Inside, the windows and the mosaics are by kolo man moser, and they're glorious. But the cleverest things are practical. The floor slopes down about twenty six centimetres from the entrance to the altar, so that everyone can see. The corners are rounded, so there's nowhere for dirt to gather. Instead of holy water standing in basins, the holy water runs, for hygiene. And there were separate entrances for men and women.

What's worth knowing is that Wagner saw no contradiction in any of this. A modern church could be beautiful and sensible at once. That's the whole of his philosophy in one building.

Opening hours are limited, so check before you make the climb.

When you've seen it, turn round and look back down the slope over the hospital pavilions. On a clear day you can see right across Vienna, and it's worth a long, slow look.
