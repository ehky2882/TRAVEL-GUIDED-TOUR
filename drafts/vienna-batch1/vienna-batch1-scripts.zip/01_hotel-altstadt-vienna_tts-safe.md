# Hotel alt shtat Vienna

A hotel is usually one person's idea, repeated sixty times. This one is sixty two ideas, and almost none of them agree.

keer khen gasser, number forty one, on the slope of shpittel berg. You're looking at a tall, pale patrician house with a modest front door and nothing in particular to announce it, which is rather the point. Behind you and downhill are the narrow lanes of shpittel berg itself, all beeder my er fronts and cobbles.

The story starts with one man, Otto Ernst vee zen tahl, who wanted his own hotel and finally got one about thirty five years ago. Instead of fitting out sixty two identical rooms, he handed them to different hands. Some were designed by the Milanese architect mat tay oh toon, others by the fashion designer ah till koo toe loo, and the newest is a suite by el freed vimmer rep themed on Sigmund Freud. No two rooms here are alike, and they're not meant to be.

Then there's the art. Up the stairs and along the corridors you'll find Warhol, bri gitta koh vants, pra khen skee, atter zay, heln vine. Some of it is on loan from museums, some belongs to vee zen tahl himself. It isn't hung like a gallery. It's hung like a house where someone collects rather more than the walls can comfortably hold.

What I like, as an architect, is that the building doesn't try to be anything. The old house does the old house job, high ceilings and deep windows, and lets the rooms argue with each other inside it. It's a very Viennese idea: a calm facade, and a great deal going on behind it.

Before you head off, walk down to shpittel berg gasser and wander the lanes for ten minutes. The little beeder my er houses are the reason this neighbourhood is protected at all, and they're at their best early in the morning, before the bars open.
