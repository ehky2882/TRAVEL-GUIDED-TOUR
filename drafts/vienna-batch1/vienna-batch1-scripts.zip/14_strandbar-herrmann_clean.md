# Strandbar Herrmann

Twenty years ago this was a patch of builders' wasteland. Then somebody tipped a load of sand on it.

You're on the Danube Canal, on the Landstraße bank, at the point where the little Wien river flows into it. Just upstream, across the mouth of the Wien river, you'll see the Urania, the domed observatory and adult education centre. On your side, along the embankment, are deckchairs, sand, and a long wooden bar. That's Strandbar Herrmann.

It opened in the summer of two thousand and five, the first of the canal's sand bars. The founder, Alexander Kaiser, had seen beach bars in Berlin and thought the idea would work here, on a neglected stretch at the mouth of the Wien river. Within days of opening, people were queuing for deckchairs.

The name has nothing to do with the owner. The little park it sits in, the Herrmannpark, is named after Emanuel Herrmann, a Viennese economist who is generally credited with inventing the postcard. I find that rather fitting for a place most visitors leave having taken a photograph.

Here's the bigger point, and it's an urban-planning one. For decades, the Danube Canal was the city's back yard: fast traffic on top, concrete walls below, nothing to stop for. The beach bars proved that people would come down to the water if you gave them a reason. The city followed, and today the canal banks are one of the liveliest public spaces in Vienna.

It's seasonal, roughly spring to early autumn, so check before you make a special trip.

[beat]

Before you leave, walk upstream along the canal path towards Schwedenplatz. The walls are covered with graffiti, much of it legal and repainted every few weeks, and on a summer evening the whole bank turns into a promenade.
