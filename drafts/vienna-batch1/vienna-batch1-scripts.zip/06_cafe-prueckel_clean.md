# Café Prückel

Most Viennese coffee houses want you to feel you've stepped back into eighteen ninety. This one stopped the clock at nineteen fifty-five.

You're at the corner of the Stubenring and Dr-Karl-Lueger-Platz, with the Ringstraße trams going past and the Museum of Applied Arts, the MAK, across the Ring. On the corner in front of you is a café with a long run of big, plain windows and an awning over the terrace. That's Café Prückel.

It opened on Christmas Day, nineteen hundred and three, under another name entirely, Café Lurion, after its founder, Maxime Lurion, a former European cycling champion. The building above was by Jakob Gartner, and the original interior was all historicist plush.

Then, in nineteen fifty-five, the architect Oswald Haerdtl was asked to modernise it. He took out the pillars and made the window openings much bigger. The result is the room you can see through the glass: light, open and quietly fifties. It's a post-war café interior that Vienna now protects as a monument, which tells you how far opinion has travelled. The rooms at the back went the other way and were rebuilt in Jugendstil style in the nineteen eighties, so you can sit in two eras at once.

Downstairs, there's a third story. In November nineteen thirty-one, the actress Stella Kadmon opened a cabaret in the basement called Der liebe Augustin. Until nineteen thirty-eight it was a stage for artists who had fled Nazi Germany, and the cellar has been a small theatre, on and off, ever since.

[beat]

Go in, take a window seat on the Ring side, and order a Prückel Creme: a small mocha with a little jug of cream on the side. Then, when you leave, walk two minutes down the Stubenring to Otto Wagner's Post Office Savings Bank, which this room would make an excellent argument with.
