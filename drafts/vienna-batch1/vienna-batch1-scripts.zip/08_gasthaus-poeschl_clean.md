# Gasthaus Pöschl

This is what Vienna means by a Beisl: a neighbourhood inn with no pretensions, wooden panelling, and a schnitzel that fills the plate.

You're on Weihburggasse, number seventeen, a step or two from the corner of Franziskanerplatz. In front of you is an unassuming shopfront with the name above it, and through the windows wood panelling, small tables, and very little else. Just round the corner to your left is the little square with the Franciscan church and its fountain.

The man behind it is Hanno Pöschl, an actor you may have seen in Before Sunrise, and a Viennese institution in his own right. He's run the Kleines Café on the square round the corner since the nineteen seventies. Around the turn of the millennium he took over this old wine room and made it a Gasthaus, and according to the city's weekly, Falter, it was the architect Hermann Czech, his collaborator on the café, who did the conversion.

That's the interesting bit, if you're an architect. Czech is famous for interiors that barely seem designed at all, rooms that look as though they've simply always been like that. Here that's exactly what you get. Nothing is new for the sake of being new. The kitchen sends out the classics, the room stays out of the way, and the Viennese come back for both.

The menu changes with the seasons, but this is the place for the dishes you came to Vienna for, done properly. It's open from lunchtime until late most days, and it's small, so it's worth booking.

[beat]

When you come out, walk round the corner onto Franziskanerplatz and stand by the Moses fountain in the middle. On the far side, at number three, is the Kleines Café, the other half of this story. Sit outside if there's a table free.
