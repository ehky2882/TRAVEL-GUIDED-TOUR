# ippen plats

If the nash markt is Vienna's market for visitors, this is the one for the people who live here.

You're on ippen plats, in otta kring, the sixteenth district, just outside the old line of the gur tel. Around you is a square lined with caffays and restaurants, with market pavilions and stalls on one side. Running off it, south along broo nen gasser, is a long street of market stalls. That's the broo nen markt, and the square is its upper end.

The market goes back to the late eighteenth century, when this was the village of noy lair khen felt, outside the city walls. Food sold inside Vienna was taxed; out here it wasn't, so traders and customers came out to the villages. The square had its own market by the end of the nineteenth century, and over time the two grew together.

Today the broo nen markt runs for nearly a kilometre and has around a hundred and seventy stalls. It's often described as one of the longest permanent street markets in Europe, and it's certainly the most international market in Vienna, with a large share of Turkish and Balkan traders among many others.

Now look round the square itself. Over the past twenty years, ippen plats has become one of the city's liveliest corners, with bakeries, caffays and restaurants spilling outside on fine days. The interesting bit is that the market never left. The new places have settled in around it rather than replacing it.

Saturday is the day to come. In the morning, farmers from around Vienna set up on ippen plats with honey, cheese, vegetables and wine, right beside the regular stalls.

Before you go, walk the whole length of the broo nen markt, from here down to tah lee ah shtrasser, and back. Buy something you can't name, ask the stallholder how to cook it, and you'll have done the broo nen markt properly.
