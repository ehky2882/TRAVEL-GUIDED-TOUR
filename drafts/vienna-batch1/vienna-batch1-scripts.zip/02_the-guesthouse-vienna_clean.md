# The Guesthouse Vienna

Some hotels shout from across the street. This one would rather you noticed the door handles.

Führichgasse, number ten, in the old city. Find the hotel's front, a plain townhouse with a brasserie at street level, then turn round. Directly opposite, up on its raised terrace, is the Albertina, the great palace of drawings and prints. The brasserie windows look straight across at it.

The design is by Sir Terence Conran and his studio, Conran and Partners, and their brief, as the hotel puts it, was no theatrical gestures and no design for design's sake. What they did instead was fill the rooms with Vienna's own modern furniture. There are pieces from the Carl Auböck workshop, the family studio that has been making brass and leather objects here for generations. There's seating by Wittmann. There are designs by Oswald Haerdtl. And beside a small library of Austrian literature, there's Friedrich Kiesler's cantilever chair.

That last one is worth a moment. Kiesler left Vienna in the nineteen twenties and became one of the great experimental architects of New York. Finding his chair here, next to the books, feels a little like a homecoming.

The brasserie downstairs is open every day of the year, from early morning to late evening. Bread comes in fresh each morning from the organic bakery Öfferl, the coffee is a house roast from the old Viennese roaster Naber, and the wine list sticks to Austria.

Here's the thing about it. The Guesthouse isn't really a Conran interior in Vienna. It's a Viennese interior, edited by an Englishman who knew when to stop.

[beat]

If you have twenty minutes, climb the ramp to the Albertina terrace opposite. Stand by the balustrade and look back at the hotel. The State Opera is a few steps away, and the view over the Burggarten palm house is one of the best free ones in the city.
