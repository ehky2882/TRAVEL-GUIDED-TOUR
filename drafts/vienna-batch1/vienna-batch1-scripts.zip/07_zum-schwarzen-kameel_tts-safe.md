# tsoom shvart sen ka mail

There has been a shop selling good things to eat on this spot since sixteen eighteen. The camel came with the founder.

You're on bogner gasser, number five, a narrow street just off the grah ben. In front of you is the shop with the camel in its name, and through the windows a long counter, usually with a small crowd standing at it. The restaurant is on the floor above.

In sixteen eighteen, a man called yo hahn baptist ka mail bought the house and opened a spice shop under his own name. ka mail, camel: a pun that has outlived him by four centuries. Two hundred years later the shtee bits family added a wine tavern, the business became a supplier to the imperial court, and Beethoven is listed among the guests. The painter ferdinand gay org valt mooler drew the camel logo you're looking at.

In nineteen hundred and one the whole building was rebuilt, and the interior was done in Viennese yoo gent shteel by the firm por twah and fix. That's the restaurant upstairs, and the house rightly calls it a yoo gent shteel jewel.

Downstairs is where the Viennese actually go. The counter is famous for very small open sandwiches, ham carved by hand, and an array of spreads. People stand, eat two or three, have a glass of wine and leave. It's an eleven in the morning habit as much as an evening one.

What's worth knowing, standing here, is that the ka mail isn't preserved because someone decided it was heritage. It's preserved because people never stopped coming.

Before you go, walk ten paces to the end of bogner gasser and look into the square am hofe, one of the largest in the old city. And on your way back to the grah ben, have a look at the engel apo tay keh at number nine, with its gilded yoo gent shteel angels on the facade.
