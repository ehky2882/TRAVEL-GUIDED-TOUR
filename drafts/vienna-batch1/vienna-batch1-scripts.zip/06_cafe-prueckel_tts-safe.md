# Caffay proo kel

Most Viennese coffee houses want you to feel you've stepped back into eighteen ninety. This one stopped the clock at nineteen fifty five.

You're at the corner of the shtooben ring and doctor karl loo eh ger plats, with the ring shtrasser trams going past and the Museum of Applied Arts, the mack, across the Ring. On the corner in front of you is a caffay with a long run of big, plain windows and an awning over the terrace. That's Caffay proo kel.

It opened on Christmas Day, nineteen hundred and three, under another name entirely, Caffay loo ree on, after its founder, max eem loo ree on, a former European cycling champion. The building above was by yah kob gartner, and the original interior was all historicist plush.

Then, in nineteen fifty five, the architect oz valt hairdl was asked to modernise it. He took out the pillars and made the window openings much bigger. The result is the room you can see through the glass: light, open and quietly fifties. It's a post war caffay interior that Vienna now protects as a monument, which tells you how far opinion has travelled. The rooms at the back went the other way and were rebuilt in yoo gent shteel style in the nineteen eighties, so you can sit in two eras at once.

Downstairs, there's a third story. In November nineteen thirty one, the actress stella kad mon opened a cabaret in the basement called dare leeber ow goos teen. Until nineteen thirty eight it was a stage for artists who had fled Nazi Germany, and the cellar has been a small theatre, on and off, ever since.

Go in, take a window seat on the Ring side, and order a proo kel krem: a small mocha with a little jug of cream on the side. Then, when you leave, walk two minutes down the shtooben ring to Otto Wagner's Post Office Savings Bank, which this room would make an excellent argument with.
