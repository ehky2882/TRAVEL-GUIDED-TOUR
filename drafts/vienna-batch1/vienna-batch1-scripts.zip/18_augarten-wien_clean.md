# Augarten Wien

Since seventeen eighteen, Vienna has been making its own porcelain. Only Meissen, in Saxony, is older in Europe.

You're on Spiegelgasse, number three, a narrow lane between the Graben and the Albertina. In front of you is the Augarten flagship shop, with white porcelain in the windows, much of it marked underneath with a small blue shield.

The story begins in May seventeen eighteen, when Emperor Charles the Sixth gave a man called Claudius Innocentius du Paquier the exclusive right to make porcelain in Austria. In seventeen forty-four the manufactory passed to Maria Theresa, and from then on every piece carried that blue shield, the old Babenberg arms, under the glaze, as a mark nobody could forge. The empress loved figurines and flowers, and you'll still see both in the windows.

The old imperial manufactory closed in eighteen sixty-four, beaten by industrial competition. In nineteen twenty-three it was revived in the baroque palace in the Augarten park, where it still is today. The new firm brought in the modern Viennese designers: Josef Hoffmann, Michael Powolny and others.

Look for one design in particular. In nineteen twenty-nine Hoffmann designed a mocha service shaped like a ribbed melon. It is still made, and the curves are notoriously difficult to paint, so if you see it decorated in fine stripes, someone with a very steady hand has spent a long time on it.

Here's the thing about Augarten. It isn't really a shop selling antiques. It's a workshop that still makes three hundred years of designs, alongside new ones.

[beat]

If you'd like to see it being made, the manufactory and its museum are in the Augarten park itself, in the second district, with guided tours of the workshop. And while you're in the park, look for the two concrete flak towers rising out of the trees. They make a very strange neighbour for a porcelain palace.
