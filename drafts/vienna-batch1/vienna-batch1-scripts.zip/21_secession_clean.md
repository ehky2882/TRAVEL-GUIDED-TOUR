# Secession

Above the door, in gold letters, it says: to every age its art, to every art its freedom. This building was the manifesto.

You're on Friedrichstraße, a few steps from the Naschmarkt. In front of you is a squat, white, almost temple-like building with very few windows, and on top a great openwork dome of gilded metal laurel leaves. The Viennese have a nickname for it, the golden cabbage. That's the Secession.

It was built in eighteen ninety-seven and eighteen ninety-eight by Joseph Maria Olbrich, then barely thirty, for a group of young artists led by Gustav Klimt who had walked out of the official art establishment. They wanted a building for exhibitions, and they wanted it to look like nothing Vienna had seen.

Now look at the details. Below that gold motto are three faces of gorgons, standing for painting, sculpture and architecture. Along the walls are owls, attributed to Koloman Moser. And the dome is a laurel crown, the symbol of victory, lifted up and made into architecture.

Then go inside, down to the basement, and you'll find Klimt's Beethoven Frieze. He painted it in nineteen hundred and two for an exhibition celebrating Beethoven, and its theme is the Ninth Symphony: humanity's search for happiness, ending in an embrace. It was meant to be temporary. It survived, and it's now back where it began.

And here's the thing. The Secession is still run by artists, as it has been since eighteen ninety-seven. It isn't a museum to a movement. It's the movement, still going.

You'll also find the building on the back of the Austrian fifty-cent coin, if you have one handy.

[beat]

When you come out, walk round to the side facing the Naschmarkt and look for the bronze of Mark Antony in his chariot, pulled by lions. Then cross over to the market, and look at the Otto Wagner houses on the far side of it, numbers thirty-eight and forty Linke Wienzeile.
