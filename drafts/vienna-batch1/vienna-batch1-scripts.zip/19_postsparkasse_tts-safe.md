# Austrian Postal Savings Bank

Look closely at the walls. They're covered in metal bolt heads, thousands of them, and for most of the last century people thought they were decoration.

You're on gay org kokh plats, a small square just off the ring shtrasser. In front of you is a vast building filling a whole city block, its walls faced in square slabs of pale marble and studded in a regular grid with small metal caps. On top of the facade stand two winged figures in shining metal. That's the Postal Savings Bank, by Otto Wagner.

It was built between nineteen hundred and four and nineteen hundred and six, with an extension in nineteen ten to nineteen twelve, in reinforced concrete, a material that was still very new. The facade is covered in thin marble slabs because marble is easy to clean. And the bolts? A study of the materials in twenty twenty four found they really were how the thin slabs were fixed over the mortar. Form and function, almost literally nailed together.

Now look up at those figures. They're by ot mar shim ko vits, over four metres tall, and they're among the first sculptures ever cast in aluminium. Aluminium turns up all over this building, in the entrance columns and the heating fans inside, because in nineteen hundred and six it was the modern metal.

Inside, up a flight of stairs, is the banking hall: a great room under a glass roof, with a floor of glass blocks that lets daylight through to the post rooms below.

The bank has moved out. The building now belongs to universities and research institutions, including the University of Applied Arts, and the banking hall has been opened to the public again.

Go in and see the hall if it's open; check the times before you come. And on your way in, look at the slim columns holding up the entrance canopy. They're aluminium too, and if you ask me they're the most modern thing on the whole square.
