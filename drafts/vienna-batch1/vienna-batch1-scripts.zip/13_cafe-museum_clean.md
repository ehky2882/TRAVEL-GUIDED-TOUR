# Café Museum

In April eighteen ninety-nine, a young critic who hated ornament got his first big job. This is it.

You're at the corner of Operngasse and Friedrichstraße, a few minutes from the State Opera. Look across Friedrichstraße and you'll see the white cube and golden dome of the Secession. Behind you, on the corner, is a large café with big windows on two sides. That's Café Museum.

The building itself dates from eighteen seventy-two. The interior was given to Adolf Loos, who was then better known for his writing than his buildings. It was his first major commission, and he treated it as a manifesto. Smooth walls, brass strips, marble tables, bentwood chairs, mirrors, and bare light bulbs. No garlands, no gilding. A plain room for people who had better things to look at.

And here's the joke. Loos despised the Secession, the gold-domed temple of ornament across the road. Yet the Secession artists adopted his café as their local. Klimt, Schiele, Kokoschka, Otto Wagner, Karl Kraus and Robert Musil all drank coffee here.

Loos's room didn't last. In nineteen thirty and thirty-one, Josef Zotti, a pupil of Josef Hoffmann, remodelled it with cosy red booths. In two thousand and three it was rebuilt to look like Loos's original, a reconstruction that critics found neither authentic nor comfortable. Since it reopened in twenty ten, the look has gone back towards Zotti: red velvet benches and round globe lamps.

What's worth knowing is that this is a room the city has argued over for a hundred and twenty-five years. Few cafés can say that.

[beat]

When you leave, cross Friedrichstraße to the Secession and read the gold lettering over its door. Then look back at the café's plain corner, and you'll be standing exactly between the two sides of the argument.
