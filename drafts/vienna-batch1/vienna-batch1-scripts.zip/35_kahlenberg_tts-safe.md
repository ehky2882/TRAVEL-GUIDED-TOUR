# kah len berg

From up here you can see the whole of Vienna at once: the old city, the river, the plain beyond. In sixteen eighty three, an army stood on this spot and looked down at a city under siege.

You're on the summit of the kah len berg, at the north western edge of the city, in the Vienna Woods. Walk to the viewing terrace. Below you, vineyards drop away down the slopes to the villages of grin tsing and nooss dorf. Beyond them, the whole city spreads out, with the spire of Saint Stephen's in the middle and the Danube on your left.

In September sixteen eighty three, Vienna had been besieged by the Ottoman army for two months. The relief army, under the Polish king yan so bee es key, gathered on these hills, and on the twelfth of September came down through the vineyards to break the siege. The little baroque church of Saint Joseph behind you, the yo zefs keer kheh, recalls it. It was destroyed in the siege, rebuilt by seventeen thirty four, and today it has a memorial chapel to so bee es key.

Now look at the view as an architect would. You can read the shape of the city from here. The tight knot of the old centre, ringed by the ring shtrasser. The big outer belt of nineteenth century districts. Then the Danube, and the modern towers of the doe now city across it. Vienna grew outward in rings, and from up here you can count them.

The terrace is open at all hours and it's free. Sunset is the busiest time; early morning is the most beautiful.

Don't take the bus back down. Take one of the footpaths down through the vineyards towards grin tsing or nooss dorf, and stop at a hoy rigger on the way for a glass of the wine you've just walked past. That, more or less, is how the Viennese spend a Sunday.
