# Knize

On the Graben, Vienna's grandest shopping street, there's a shopfront by Adolf Loos that has barely changed in more than a century.

You're on the Graben, at number thirteen. Find the shopfront with the name Knize spelled out above it, in a band of polished dark stone around the door and windows. Turn round and the Plague Column, with its swirling cloud of saints, is behind you in the middle of the street.

The firm was founded in eighteen fifty-eight by a Czech tailor, Josef Kniže, who made riding clothes, sporting wear and liveries for Vienna's grand households. Between nineteen ten and nineteen thirteen, Adolf Loos designed this shop. It has survived almost unaltered, which is rare for any Loos interior, let alone one still doing the job it was built for.

Loos thought ornament belonged to the past, but he never thought luxury did. Look at the way the front is made: plain, dark, beautifully proportioned, the lettering doing almost all of the decoration. Inside, the rooms are lined in wood and feel more like a gentleman's club than a shop.

The client list is a little startling. Marlene Dietrich had her stage tailcoats made here. Oskar Kokoschka, Billy Wilder, Josephine Baker and Georgia O'Keeffe are all on it. Loos even designed a second Knize shop on the Champs-Élysées in Paris in the late nineteen twenties.

And the craft continues. The art of making tailcoats to measure is on Austria's list of intangible cultural heritage, and Knize is one of the last workshops still doing it by hand, in the master workshop here on the Graben.

[beat]

Before you go, walk a few doors along to the Graben's crossing with Kohlmarkt, then look down Kohlmarkt to the Michaelerplatz. The plain building facing the palace gate at the end is Loos's Looshaus, the one that so offended the Emperor.
