# house vit gen shtine

One of the twentieth century's great philosophers spent two years designing a house for his sister. He once had a ceiling raised by three centimetres because the proportions weren't quite right.

You're on koond man gasser, in the third district, at number nineteen. Behind a garden wall you'll see a stark, white, blocky house of several stacked volumes, with tall plain windows and no decoration of any kind. That's house vit gen shtine.

It was commissioned in nineteen twenty five by margaret stone burra vit gen shtine, a wealthy patron of the arts and the subject of a famous portrait by Klimt. She hired the architect paul eng el man, a pupil of adolf lohs, and then invited her brother lood vig, the philosopher, to help. lood vig became so involved that eng el man later considered him the real author.

lood vig worried at every detail. He designed the windows, the doors, the radiators and the door handles himself. Each window had a heavy metal screen, about a hundred and fifty kilos, that he arranged to move on a pulley. And that ceiling: raised thirty millimetres, because it was wrong. The house was finished in December nineteen twenty eight, in time for the family to spend Christmas there.

Even he had doubts. lood vig said the house had good manners but no primordial life or health.

It nearly didn't survive. In nineteen sixty eight it was sold to a developer to be pulled down. A campaign saved it, it became a national monument in nineteen seventy one, and it's housed the cultural department of the Bulgarian Embassy ever since. Access to the inside varies, so check ahead.

Stand back from the wall for a moment and look at the proportions of the windows against the white walls. Then walk ten minutes or so to the rokh oos markt, a cheerful local market square, and remind yourself what life looks like when nobody is measuring it in millimetres.
